
"use client"

import { Product } from "@/types";
import { Button } from "@/components/ui/button";
import { Plus, ShoppingBag } from "lucide-react";
import Image from "next/image";
import { useCart } from "@/hooks/use-cart";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();
  const { toast } = useToast();

  const handleAddToCart = () => {
    addItem(product);
    toast({
      title: "Added to Cart",
      description: `${product.name} has been added to your collection.`,
    });
  };

  return (
    <Card className="group glass-morphism glass-morphism-hover overflow-hidden border-0 rounded-2xl">
      <div className="relative aspect-square overflow-hidden">
        <Image 
          src={product.imageUrl} 
          alt={product.name}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <Button 
            className="bg-white text-background hover:bg-white/90 rounded-full"
            onClick={handleAddToCart}
          >
            <Plus className="w-4 h-4 mr-2" />
            Quick Add
          </Button>
        </div>
      </div>
      <CardContent className="p-5 space-y-2">
        <div className="flex justify-between items-start">
          <h3 className="font-headline text-lg font-bold group-hover:text-primary transition-colors">{product.name}</h3>
          <span className="text-primary font-bold font-body">${product.price.toFixed(2)}</span>
        </div>
        <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">
          {product.description}
        </p>
      </CardContent>
      <CardFooter className="px-5 pb-5 pt-0">
        <Button 
          variant="outline" 
          className="w-full border-white/10 hover:border-primary hover:text-primary transition-all rounded-xl"
          onClick={handleAddToCart}
        >
          <ShoppingBag className="w-4 h-4 mr-2" />
          Add to Bag
        </Button>
      </CardFooter>
    </Card>
  );
}
