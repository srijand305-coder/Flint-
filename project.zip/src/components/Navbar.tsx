
"use client"

import Link from "next/link";
import { Flame, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/use-cart";
import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle, 
  SheetTrigger 
} from "@/components/ui/sheet";
import { CartSheet } from "./CartSheet";

export function Navbar() {
  const { items } = useCart();
  const itemCount = items.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-white/10 bg-background/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <Flame className="w-6 h-6 text-primary group-hover:scale-110 transition-transform" />
          <span className="font-headline text-xl font-bold tracking-tight">FLINT & LIGHT</span>
        </Link>

        <div className="hidden md:flex items-center gap-8 text-sm font-medium uppercase tracking-widest">
          <Link href="#products" className="hover:text-primary transition-colors">Collection</Link>
          <Link href="#about" className="hover:text-primary transition-colors">Our Story</Link>
        </div>

        <div className="flex items-center gap-2">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="relative hover:bg-white/10">
                <ShoppingCart className="w-5 h-5" />
                {itemCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-accent text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                    {itemCount}
                  </span>
                )}
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full sm:max-w-md glass-morphism border-l border-white/10 text-foreground">
              <SheetHeader>
                <SheetTitle className="font-headline text-2xl text-primary">Your Collection</SheetTitle>
              </SheetHeader>
              <CartSheet />
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
