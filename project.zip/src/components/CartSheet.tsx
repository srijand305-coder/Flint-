
"use client"

import { useCart } from "@/hooks/use-cart";
import { Button } from "@/components/ui/button";
import { Minus, Plus, Trash2 } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useFirestore } from "@/firebase";
import { collection, doc } from "firebase/firestore";
import { setDocumentNonBlocking } from "@/firebase/non-blocking-updates";

export function CartSheet() {
  const { items, removeItem, updateQuantity, getSubtotal, getDiscount, getTotal, clearCart } = useCart();
  const { toast } = useToast();
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [formData, setFormData] = useState({ name: '', phone: '', address: '' });
  const firestore = useFirestore();

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.address) {
      toast({ title: "Error", description: "Please fill in all fields.", variant: "destructive" });
      return;
    }

    try {
      const orderId = crypto.randomUUID();
      const orderRef = doc(firestore, 'orders', orderId);
      
      const orderData = {
        id: orderId,
        customerName: formData.name,
        customerPhone: formData.phone,
        customerAddress: formData.address,
        totalAmount: getTotal(),
        orderDate: new Date().toISOString(),
        status: 'pending',
        discountApplied: getDiscount() > 0,
        discountPercentage: getDiscount() > 0 ? 10 : 0,
        orderItemIds: items.map(i => i.id)
      };

      setDocumentNonBlocking(orderRef, orderData, { merge: true });

      // In a real app, we would also add order items to the subcollection
      // but for this MVP we store the essential order details at the top level

      toast({ title: "Order Placed!", description: "Your subtle flame is on its way." });
      clearCart();
      setIsCheckingOut(false);
      setFormData({ name: '', phone: '', address: '' });
    } catch (error) {
      toast({ title: "Error", description: "Something went wrong. Please try again.", variant: "destructive" });
    }
  };

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-4 text-muted-foreground">
        <p className="font-headline text-lg italic">Your collection is empty.</p>
        <Button variant="outline" onClick={() => window.location.hash = 'products'}>Browse Candles</Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full pt-6">
      {!isCheckingOut ? (
        <>
          <ScrollArea className="flex-1 pr-4">
            <div className="space-y-6">
              {items.map((item) => (
                <div key={item.id} className="flex justify-between items-start gap-4">
                  <div className="flex-1">
                    <h4 className="font-headline font-semibold text-foreground">{item.name}</h4>
                    <p className="text-sm text-primary font-bold">${item.price.toFixed(2)}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => updateQuantity(item.id, -1)}><Minus className="h-3 w-3" /></Button>
                      <span className="text-sm w-4 text-center">{item.quantity}</span>
                      <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => updateQuantity(item.id, 1)}><Plus className="h-3 w-3" /></Button>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive" onClick={() => removeItem(item.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </ScrollArea>

          <div className="mt-auto space-y-4 py-6">
            <Separator className="bg-white/10" />
            <div className="space-y-1.5">
              <div className="flex justify-between text-sm">
                <span>Subtotal</span>
                <span>${getSubtotal().toFixed(2)}</span>
              </div>
              {getDiscount() > 0 && (
                <div className="flex justify-between text-sm text-accent">
                  <span>Bulk Discount (10%)</span>
                  <span>-${getDiscount().toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-lg">
                <span>Total</span>
                <span className="text-primary">${getTotal().toFixed(2)}</span>
              </div>
            </div>
            <Button className="w-full bg-primary hover:bg-primary/90 text-white font-bold" onClick={() => setIsCheckingOut(true)}>
              Checkout Now
            </Button>
            <p className="text-[10px] text-center text-muted-foreground">
              Add 5 or more candles to receive a 10% bulk discount.
            </p>
          </div>
        </>
      ) : (
        <form onSubmit={handleCheckout} className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input 
                id="name" 
                value={formData.name} 
                onChange={e => setFormData({ ...formData, name: e.target.value })} 
                placeholder="John Doe"
                className="bg-white/5"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input 
                id="phone" 
                value={formData.phone} 
                onChange={e => setFormData({ ...formData, phone: e.target.value })} 
                placeholder="+91 999 000 0000"
                className="bg-white/5"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Delivery Address</Label>
              <Input 
                id="address" 
                value={formData.address} 
                onChange={e => setFormData({ ...formData, address: e.target.value })} 
                placeholder="Varanasi Ghats, Uttar Pradesh"
                className="bg-white/5"
              />
            </div>
          </div>
          <div className="pt-4 space-y-3">
            <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-white font-bold">
              Confirm Order (${getTotal().toFixed(2)})
            </Button>
            <Button variant="ghost" className="w-full" onClick={() => setIsCheckingOut(false)}>
              Back to Cart
            </Button>
          </div>
        </form>
      )}
    </div>
  );
}
