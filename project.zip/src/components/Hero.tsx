
"use client"

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ChevronDown, Sparkles } from "lucide-react";
import { generateHeroContentSuggestions, GenerateHeroContentSuggestionsOutput } from "@/ai/flows/generate-hero-content-suggestions-flow";
import { PlaceHolderImages } from "@/lib/placeholder-images";

export function Hero() {
  const [aiSuggestions, setAiSuggestions] = useState<GenerateHeroContentSuggestionsOutput | null>(null);
  const [currentHint, setCurrentHint] = useState<string>("Handcrafted luxury candles for your sanctuary.");
  
  const heroImage = PlaceHolderImages.find(img => img.id === 'hero-bg');

  const fetchAiSuggestions = async () => {
    try {
      const suggestions = await generateHeroContentSuggestions({});
      setAiSuggestions(suggestions);
      if (suggestions.textPrompts.length > 0) {
        setCurrentHint(suggestions.textPrompts[0]);
      }
    } catch (error) {
      console.error("AI Error:", error);
    }
  };

  return (
    <section className="relative h-[90vh] w-full flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <Image 
          src={heroImage?.imageUrl || "https://picsum.photos/seed/flint-hero/1920/1080"} 
          alt="Luxury Candle Ambience"
          fill
          className="object-cover opacity-60"
          priority
          data-ai-hint="candlelight dark"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/60 to-background" />
      </div>

      <div className="container relative z-10 px-4 text-center space-y-8 max-w-4xl">
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-8 duration-1000">
          <p className="text-primary font-bold tracking-[0.3em] uppercase text-sm">Est. 2024</p>
          <h1 className="font-headline text-5xl md:text-8xl lg:text-9xl font-bold tracking-tighter leading-none">
            SUBTLE FLAME <br />
            <span className="text-primary">LASTINGPRESENCE.</span>
          </h1>
          <p className="text-muted-foreground text-lg md:text-xl font-medium italic max-w-2xl mx-auto">
            {currentHint}
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4 animate-in fade-in slide-in-from-bottom-12 duration-1000 delay-300">
          <Button size="lg" className="bg-primary hover:bg-primary/90 text-white font-bold h-12 px-10 rounded-full" asChild>
            <Link href="#products">Shop Collection</Link>
          </Button>
          <Button variant="outline" size="lg" className="border-white/20 hover:bg-white/10 h-12 px-10 rounded-full" onClick={fetchAiSuggestions}>
            <Sparkles className="mr-2 w-4 h-4 text-primary" />
            AI Inspiration
          </Button>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
        <ChevronDown className="w-6 h-6 text-muted-foreground" />
      </div>
    </section>
  );
}
