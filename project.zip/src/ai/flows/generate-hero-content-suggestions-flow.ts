'use server';
/**
 * @fileOverview A GenAI tool to generate creative, cinematic imagery concepts and descriptive text prompts for the storefront's hero section.
 *
 * - generateHeroContentSuggestions - A function that handles the generation process.
 * - GenerateHeroContentSuggestionsInput - The input type for the generateHeroContentSuggestions function.
 * - GenerateHeroContentSuggestionsOutput - The return type for the generateHeroContentSuggestions function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateHeroContentSuggestionsInputSchema = z.object({});
export type GenerateHeroContentSuggestionsInput = z.infer<typeof GenerateHeroContentSuggestionsInputSchema>;

const GenerateHeroContentSuggestionsOutputSchema = z.object({
  imageryConcepts: z.array(z.string()).describe('A list of cinematic imagery concepts for the hero section.'),
  textPrompts: z.array(z.string()).describe('A list of descriptive text prompts that evoke the brand essence for the hero section.'),
});
export type GenerateHeroContentSuggestionsOutput = z.infer<typeof GenerateHeroContentSuggestionsOutputSchema>;

export async function generateHeroContentSuggestions(input: GenerateHeroContentSuggestionsInput): Promise<GenerateHeroContentSuggestionsOutput> {
  return generateHeroContentSuggestionsFlow(input);
}

const heroContentPrompt = ai.definePrompt({
  name: 'heroContentPrompt',
  input: {schema: GenerateHeroContentSuggestionsInputSchema},
  output: {schema: GenerateHeroContentSuggestionsOutputSchema},
  prompt: `You are a creative director and marketing expert for a luxury candle brand named 'Flint & Light'.
Your task is to generate compelling, cinematic imagery concepts and evocative descriptive text prompts for the e-commerce storefront's hero section.
The hero section prominently features the headline: 'SUBTLE FLAME LASTINGPRESENCE.'

The brand aesthetic is:
-   **Theme**: Professional, dark-themed, elegant.
-   **Colors**: Primary: rich, subdued copper (#DD8C3C). Background: deep, warm dark grey-brown (#251F18). Accent: muted rosy red (#DB7070).
-   **Typography**: Headline font: 'Playfair' (serif, elegant, high-contrast). Body font: 'PT Sans' (sans-serif, clean readability).
-   **Style**: 'Glassmorphism' product grid, minimalist outline icons, subtle hover effects and transition animations.

Based on this, suggest 3-5 distinct and creative cinematic imagery concepts and 3-5 descriptive text prompts.
The text prompts should resonate with the 'SUBTLE FLAME LASTINGPRESENCE.' headline and the overall brand identity.
Focus on warmth, elegance, subtle luxury, and timelessness.
Ensure the imagery concepts are highly visual and inspiring for an AI image generation model, and the text prompts are short, impactful, and poetic.

Return your suggestions in the specified JSON format.`,
});

const generateHeroContentSuggestionsFlow = ai.defineFlow(
  {
    name: 'generateHeroContentSuggestionsFlow',
    inputSchema: GenerateHeroContentSuggestionsInputSchema,
    outputSchema: GenerateHeroContentSuggestionsOutputSchema,
  },
  async input => {
    const {output} = await heroContentPrompt(input);
    if (!output) {
      throw new Error('Failed to generate hero content suggestions.');
    }
    return output;
  }
);
