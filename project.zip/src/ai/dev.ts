import { config } from 'dotenv';
config();

import '@/ai/flows/generate-hero-content-suggestions-flow.ts';