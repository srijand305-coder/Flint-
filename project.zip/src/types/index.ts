
export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  imageUrl: string;
  category: string;
  stockQuantity?: number;
  createdAt?: any;
  updatedAt?: any;
}

export interface OrderItem {
  id: string;
  orderId: string;
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
}

export interface Order {
  id: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  totalAmount: number;
  orderDate: string;
  status: string;
  discountApplied: boolean;
  discountPercentage?: number;
  orderItemIds: string[];
}
