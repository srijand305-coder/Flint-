
"use client"

import { useState, useEffect } from "react";
import { useAuth, useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, doc, serverTimestamp } from "firebase/firestore";
import { setDocumentNonBlocking, deleteDocumentNonBlocking } from "@/firebase/non-blocking-updates";
import { initiateAnonymousSignIn } from "@/firebase/non-blocking-login";
import { signOut } from "firebase/auth";
import { Product, Order } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  Plus, 
  Trash2, 
  LogOut, 
  LayoutDashboard, 
  Package, 
  ShoppingCart,
  TrendingUp,
  Flame
} from "lucide-react";
import { format } from "date-fns";

export default function AdminPage() {
  const { user, isUserLoading } = useUser();
  const [isAccessGranted, setIsAccessGranted] = useState(false);
  const [password, setPassword] = useState("");
  const { toast } = useToast();

  const firestore = useFirestore();
  const auth = useAuth();

  // Check for session persistence on load
  useEffect(() => {
    const granted = localStorage.getItem('flint_admin_access') === 'true';
    if (granted && user) {
      setIsAccessGranted(true);
    }
  }, [user]);

  // Firestore Queries - Only active when authenticated and access is granted
  const productsQuery = useMemoFirebase(() => {
    if (!isAccessGranted || !user) return null;
    return collection(firestore, 'products');
  }, [firestore, isAccessGranted, user]);

  const ordersQuery = useMemoFirebase(() => {
    if (!isAccessGranted || !user) return null;
    return collection(firestore, 'orders');
  }, [firestore, isAccessGranted, user]);

  const { data: products } = useCollection<Product>(productsQuery);
  const { data: orders } = useCollection<Order>(ordersQuery);

  const [newProduct, setNewProduct] = useState({ name: "", price: "", description: "", imageUrl: "", category: "" });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "1234") {
      initiateAnonymousSignIn(auth);
      setIsAccessGranted(true);
      localStorage.setItem('flint_admin_access', 'true');
      toast({ title: "Welcome back", description: "Varanasi's finest collection is at your command." });
    } else {
      toast({ title: "Access Denied", description: "Incorrect security code.", variant: "destructive" });
    }
  };

  const handleLogout = () => {
    signOut(auth);
    setIsAccessGranted(false);
    localStorage.removeItem('flint_admin_access');
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.name || !newProduct.price || !newProduct.imageUrl) return;

    const productId = crypto.randomUUID();
    const productRef = doc(firestore, 'products', productId);
    
    setDocumentNonBlocking(productRef, {
      id: productId,
      ...newProduct,
      price: parseFloat(newProduct.price),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      stockQuantity: 100 
    }, { merge: true });

    setNewProduct({ name: "", price: "", description: "", imageUrl: "", category: "" });
    toast({ title: "Product Added", description: `${newProduct.name} is now in the collection.` });
  };

  const handleDeleteProduct = (id: string) => {
    const productRef = doc(firestore, 'products', id);
    deleteDocumentNonBlocking(productRef);
    toast({ title: "Product Removed", description: "Item has been deleted from the database." });
  };

  const handleDeleteOrder = (id: string) => {
    const orderRef = doc(firestore, 'orders', id);
    deleteDocumentNonBlocking(orderRef);
    toast({ title: "Order Removed", description: "The order has been removed from history." });
  };

  const totalRevenue = orders?.reduce((acc, order) => acc + (order.totalAmount || 0), 0) || 0;

  if (isUserLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Flame className="w-12 h-12 text-primary animate-pulse" />
      </div>
    );
  }

  if (!isAccessGranted || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background px-4">
        <Card className="w-full max-w-md glass-morphism border-white/10">
          <CardHeader className="text-center">
            <Flame className="w-12 h-12 text-primary mx-auto mb-4" />
            <CardTitle className="font-headline text-3xl tracking-tight">FLINT & LIGHT</CardTitle>
            <CardDescription className="uppercase tracking-widest text-[10px]">Internal Owner Portal</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password">Security Code</Label>
                <Input 
                  id="password" 
                  type="password" 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)} 
                  className="bg-white/5 border-white/10"
                  placeholder="Enter Access Key"
                  autoFocus
                />
              </div>
              <Button type="submit" className="w-full bg-primary hover:bg-primary/90">Verify Identity</Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-white/10 bg-secondary/50 backdrop-blur-md h-16 sticky top-0 z-50">
        <div className="container mx-auto px-4 h-full flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Flame className="w-6 h-6 text-primary" />
            <span className="font-headline font-bold text-xl uppercase tracking-widest">Internal Portal</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs text-muted-foreground hidden sm:inline">Varanasi Headquarters</span>
            <Button variant="ghost" size="icon" onClick={handleLogout} className="hover:bg-white/10">
              <LogOut className="w-5 h-5 text-muted-foreground" />
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="dashboard" className="space-y-8">
          <TabsList className="bg-white/5 border border-white/10">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-primary"><LayoutDashboard className="w-4 h-4 mr-2" />Dashboard</TabsTrigger>
            <TabsTrigger value="inventory" className="data-[state=active]:bg-primary"><Package className="w-4 h-4 mr-2" />Inventory</TabsTrigger>
            <TabsTrigger value="orders" className="data-[state=active]:bg-primary"><ShoppingCart className="w-4 h-4 mr-2" />Order Stream</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="glass-morphism border-white/10">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium uppercase tracking-widest text-muted-foreground">Total Revenue</CardTitle>
                  <TrendingUp className="h-4 w-4 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-primary">${totalRevenue.toFixed(2)}</div>
                  <p className="text-xs text-muted-foreground">Earnings from the store.</p>
                </CardContent>
              </Card>
              <Card className="glass-morphism border-white/10">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium uppercase tracking-widest text-muted-foreground">Total Orders</CardTitle>
                  <ShoppingCart className="h-4 w-4 text-accent" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{orders?.length || 0}</div>
                  <p className="text-xs text-muted-foreground">Client requests fulfilled.</p>
                </CardContent>
              </Card>
              <Card className="glass-morphism border-white/10">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium uppercase tracking-widest text-muted-foreground">Active Items</CardTitle>
                  <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{products?.length || 0}</div>
                  <p className="text-xs text-muted-foreground">Items in collection.</p>
                </CardContent>
              </Card>
            </div>

            <Card className="glass-morphism border-white/10">
              <CardHeader>
                <CardTitle className="font-headline text-2xl">Recent Activity</CardTitle>
                <CardDescription>Live notifications from Varanasi.</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow className="border-white/10 hover:bg-transparent">
                      <TableHead>Customer</TableHead>
                      <TableHead>Contact</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                      <TableHead className="w-10"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders?.slice(0, 5).map((order) => (
                      <TableRow key={order.id} className="border-white/5">
                        <TableCell className="font-bold">{order.customerName}</TableCell>
                        <TableCell className="text-muted-foreground">{order.customerPhone}</TableCell>
                        <TableCell className="text-right text-primary font-bold">${(order.totalAmount || 0).toFixed(2)}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive" onClick={() => handleDeleteOrder(order.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {(!orders || orders.length === 0) && (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-10 text-muted-foreground italic">No recent activity detected.</TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="inventory" className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <Card className="glass-morphism border-white/10 lg:col-span-1 h-fit">
                <CardHeader>
                  <CardTitle className="font-headline text-2xl">Add New Candle</CardTitle>
                  <CardDescription>Publish a new creation to the store.</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleAddProduct} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="prod-name">Product Name</Label>
                      <Input id="prod-name" placeholder="E.g. Saffron Ember" value={newProduct.name} onChange={e => setNewProduct({...newProduct, name: e.target.value})} className="bg-white/5" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="prod-price">Price ($)</Label>
                      <Input id="prod-price" type="number" step="0.01" placeholder="24.99" value={newProduct.price} onChange={e => setNewProduct({...newProduct, price: e.target.value})} className="bg-white/5" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="prod-desc">Description</Label>
                      <Input id="prod-desc" placeholder="Notes of vanilla and wood..." value={newProduct.description} onChange={e => setNewProduct({...newProduct, description: e.target.value})} className="bg-white/5" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="prod-img">Image URL</Label>
                      <Input id="prod-img" placeholder="https://picsum.photos/..." value={newProduct.imageUrl} onChange={e => setNewProduct({...newProduct, imageUrl: e.target.value})} className="bg-white/5" />
                    </div>
                    <Button type="submit" className="w-full bg-primary hover:bg-primary/90 mt-4">
                      <Plus className="w-4 h-4 mr-2" /> Publish Item
                    </Button>
                  </form>
                </CardContent>
              </Card>

              <Card className="glass-morphism border-white/10 lg:col-span-2">
                <CardHeader>
                  <CardTitle className="font-headline text-2xl">Collection Archive</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {products?.map((p) => (
                      <div key={p.id} className="p-4 rounded-xl border border-white/10 bg-white/5 flex items-center justify-between group">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-lg bg-white/10 overflow-hidden shrink-0">
                             <img src={p.imageUrl} alt={p.name} className="object-cover w-full h-full" />
                          </div>
                          <div>
                            <p className="font-bold text-sm">{p.name}</p>
                            <p className="text-xs text-primary">${p.price.toFixed(2)}</p>
                          </div>
                        </div>
                        <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive" onClick={() => handleDeleteProduct(p.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                    {(!products || products.length === 0) && <p className="col-span-2 text-center py-10 text-muted-foreground italic">Archive is currently empty.</p>}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="orders">
            <Card className="glass-morphism border-white/10">
              <CardHeader>
                <CardTitle className="font-headline text-2xl">Complete Order History</CardTitle>
                <CardDescription>A record of all client interactions.</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow className="border-white/10 hover:bg-transparent">
                      <TableHead>Date</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                      <TableHead className="w-10"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders?.map((order) => (
                      <TableRow key={order.id} className="border-white/5">
                        <TableCell className="text-xs text-muted-foreground">
                          {order.orderDate ? format(new Date(order.orderDate), "MMM dd, HH:mm") : 'N/A'}
                        </TableCell>
                        <TableCell>
                          <p className="font-bold">{order.customerName}</p>
                          <p className="text-xs text-muted-foreground">{order.customerPhone}</p>
                        </TableCell>
                        <TableCell className="text-right text-primary font-bold">${(order.totalAmount || 0).toFixed(2)}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive" onClick={() => handleDeleteOrder(order.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
