
"use client"

import { useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection } from "firebase/firestore";
import { Product } from "@/types";
import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { ProductCard } from "@/components/ProductCard";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import Image from "next/image";
import { Flame, MapPin, Phone, Mail, Instagram, Facebook, Twitter } from "lucide-react";
import Link from "next/link";

export default function Home() {
  const firestore = useFirestore();
  const productsQuery = useMemoFirebase(() => collection(firestore, 'products'), [firestore]);
  const { data: products, isLoading: loading } = useCollection<Product>(productsQuery);

  const aboutImage = PlaceHolderImages.find(img => img.id === 'about-image');

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        <Hero />

        {/* Product Grid Section */}
        <section id="products" className="py-24 container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-4">
            <div className="space-y-2">
              <h2 className="text-primary font-bold tracking-widest uppercase text-sm">The Flint & Light Collection</h2>
              <h3 className="font-headline text-4xl md:text-5xl font-bold">Curated Essence</h3>
            </div>
            <p className="text-muted-foreground max-w-sm text-sm font-medium">
              Hand-poured with love and premium ingredients, designed to bring a lasting presence to your space.
            </p>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="aspect-[4/5] animate-pulse bg-white/5 rounded-2xl" />
              ))}
            </div>
          ) : products && products.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 glass-morphism rounded-3xl">
              <p className="font-headline text-2xl italic text-muted-foreground">The collection is being replenished...</p>
            </div>
          )}
        </section>

        {/* About Section */}
        <section id="about" className="py-24 bg-secondary/30">
          <div className="container mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl">
              <Image 
                src={aboutImage?.imageUrl || "https://picsum.photos/seed/artisan/800/600"} 
                alt="Our Process"
                fill
                className="object-cover"
                data-ai-hint="candle making"
              />
            </div>
            <div className="space-y-8">
              <div className="space-y-4">
                <h2 className="text-primary font-bold tracking-widest uppercase text-sm">Our Story</h2>
                <h3 className="font-headline text-4xl md:text-5xl font-bold">Crafted for the Timeless</h3>
              </div>
              <div className="space-y-6 text-muted-foreground leading-relaxed text-lg">
                <p>
                  At Flint & Light, we believe that a candle is more than just a source of light; it is a companion to your most intimate moments. 
                  Our journey began with a simple desire: to create scents that linger in the memory as long as they do in the air.
                </p>
                <p>
                  Every Flint & Light candle is hand-poured in small batches, using only the finest soy wax, lead-free cotton wicks, and phthalate-free fragrance oils. 
                  We call it a "subtle flame" because it doesn't shout, but its presence is unmistakable.
                </p>
              </div>
              <div className="grid grid-cols-3 gap-8 pt-4">
                <div className="text-center space-y-1">
                  <p className="text-2xl font-bold text-primary">100%</p>
                  <p className="text-xs uppercase tracking-tighter text-muted-foreground">Organic Soy</p>
                </div>
                <div className="text-center space-y-1">
                  <p className="text-2xl font-bold text-primary">40h+</p>
                  <p className="text-xs uppercase tracking-tighter text-muted-foreground">Burn Time</p>
                </div>
                <div className="text-center space-y-1">
                  <p className="text-2xl font-bold text-primary">0%</p>
                  <p className="text-xs uppercase tracking-tighter text-muted-foreground">Synthetic Additives</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-background border-t border-white/10 pt-20 pb-10">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <Link href="/" className="flex items-center gap-2">
              <Flame className="w-8 h-8 text-primary" />
              <span className="font-headline text-2xl font-bold tracking-tight">FLINT & LIGHT</span>
            </Link>
            <p className="text-muted-foreground leading-relaxed text-sm">
              Bringing warmth and elegance to every corner of your home with our meticulously crafted candle collection.
            </p>
            <div className="flex items-center gap-4">
              <Link href="#" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:bg-primary hover:text-white transition-all"><Instagram className="w-4 h-4" /></Link>
              <Link href="#" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:bg-primary hover:text-white transition-all"><Facebook className="w-4 h-4" /></Link>
              <Link href="#" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:bg-primary hover:text-white transition-all"><Twitter className="w-4 h-4" /></Link>
            </div>
          </div>

          <div className="space-y-6">
            <h4 className="font-headline text-lg font-bold">Quick Links</h4>
            <ul className="space-y-4 text-sm text-muted-foreground">
              <li><Link href="#products" className="hover:text-primary transition-colors">Our Collection</Link></li>
              <li><Link href="#about" className="hover:text-primary transition-colors">The Brand Story</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Bulk Orders</Link></li>
            </ul>
          </div>

          <div className="space-y-6">
            <h4 className="font-headline text-lg font-bold">Customer Care</h4>
            <ul className="space-y-4 text-sm text-muted-foreground">
              <li><Link href="#" className="hover:text-primary transition-colors">Shipping Policy</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Returns & Refunds</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">FAQs</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Terms of Service</Link></li>
            </ul>
          </div>

          <div className="space-y-6">
            <h4 className="font-headline text-lg font-bold">Contact Us</h4>
            <ul className="space-y-4 text-sm text-muted-foreground">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-primary shrink-0" />
                <span>Varanasi Ghats, Uttar Pradesh, India</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-primary shrink-0" />
                <span>+91 999 000 0000</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-primary shrink-0" />
                <span>hello@flintlight.com</span>
              </li>
            </ul>
          </div>
        </div>
        <div className="container mx-auto px-4 pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] uppercase tracking-widest text-muted-foreground">
          <p>© 2024 Flint & Light. All rights reserved.</p>
          <p>Handcrafted in Varanasi</p>
        </div>
      </footer>
    </div>
  );
}
