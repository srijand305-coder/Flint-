
import { initializeApp, getApps, getApp } from "firebase/app";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyDummyKey-For-UI-Mockup",
  authDomain: "flint-and-light.firebaseapp.com",
  databaseURL: "https://flint-and-light-default-rtdb.firebaseio.com",
  projectId: "flint-and-light",
  storageBucket: "flint-and-light.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdef"
};

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const db = getDatabase(app);

export { db };
