export const firebaseConfig = {
  "projectId": "studio-3183590485-b5726",
  "appId": "1:620539673172:web:8255f7d4152f7d44638bc1",
  "apiKey": "AIzaSyBIFItUNaQflvmerRE68AXjArjwSMAX2r8",
  "authDomain": "studio-3183590485-b5726.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "620539673172"
};
