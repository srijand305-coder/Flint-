
"use client"

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { OrderItem, Product } from '@/types';

interface CartStore {
  items: OrderItem[];
  addItem: (product: Product) => void;
  removeItem: (id: string) => void;
  updateQuantity: (id: string, delta: number) => void;
  clearCart: () => void;
  getSubtotal: () => number;
  getDiscount: () => number;
  getTotal: () => number;
}

export const useCart = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      addItem: (product) => {
        const items = get().items;
        const existing = items.find(i => i.id === product.id);
        if (existing) {
          set({ items: items.map(i => i.id === product.id ? { ...i, quantity: i.quantity + 1 } : i) });
        } else {
          set({ items: [...items, { id: product.id, name: product.name, price: product.price, quantity: 1 }] });
        }
      },
      removeItem: (id) => set({ items: get().items.filter(i => i.id !== id) }),
      updateQuantity: (id, delta) => {
        const items = get().items;
        set({
          items: items.map(i => {
            if (i.id === id) {
              const newQty = Math.max(1, i.quantity + delta);
              return { ...i, quantity: newQty };
            }
            return i;
          })
        });
      },
      clearCart: () => set({ items: [] }),
      getSubtotal: () => {
        return get().items.reduce((acc, item) => acc + item.price * item.quantity, 0);
      },
      getDiscount: () => {
        const items = get().items;
        const totalQty = items.reduce((acc, item) => acc + item.quantity, 0);
        const subtotal = get().getSubtotal();
        // 10% discount for 5 or more items
        return totalQty >= 5 ? subtotal * 0.1 : 0;
      },
      getTotal: () => {
        return get().getSubtotal() - get().getDiscount();
      }
    }),
    { name: 'flint-light-cart' }
  )
);
