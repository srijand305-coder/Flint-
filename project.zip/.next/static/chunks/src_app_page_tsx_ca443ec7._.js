(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_bdb4ea44._.js",
  "static/chunks/node_modules_699b45b4._.js"
],
    source: "dynamic"
});
