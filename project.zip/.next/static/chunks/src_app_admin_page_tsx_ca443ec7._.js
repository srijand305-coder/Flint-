(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_1fd2a7f9._.js",
  "static/chunks/node_modules_87a963fb._.js"
],
    source: "dynamic"
});
