(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_0227ce35._.js",
  "static/chunks/node_modules_34cc743c._.js"
],
    source: "dynamic"
});
