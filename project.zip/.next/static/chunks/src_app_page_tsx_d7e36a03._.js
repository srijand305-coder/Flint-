(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_e5633f1a._.js",
  "static/chunks/94568_@firebase_auth_dist_esm2017_39867e80._.js",
  "static/chunks/node_modules_next_2b366de9._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_d9c36ae7.js",
  "static/chunks/node_modules_fd1fe160._.js"
],
    source: "dynamic"
});
