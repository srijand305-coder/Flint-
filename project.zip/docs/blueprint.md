# **App Name**: Flint & Light

## Core Features:

- Customer Storefront Navigation: Browse candles through a Glassmorphism product grid, view the 'SUBTLE FLAME LASTINGPRESENCE.' cinematic hero section, explore 'About' details, and navigate using a professional multi-column sitemap footer.
- Shopping Cart & Bulk Pricing: Add products to a shopping cart, with an automatic 10% discount applied to orders of 5 or more items during checkout.
- Owner Portal Access Control: Secure the owner's administrative dashboard with password protection using 'Ganyth'.
- Live Sales Dashboard: Monitor total revenue and a real-time order stream showing customer name, phone, address, quantity, and total for each order.
- Product Inventory Management: Add new candle products and remove existing ones from the database via the Owner Portal.
- Firebase Realtime Data Sync: Ensure live synchronization of product and order data between the Customer Storefront and Owner Portal using Firebase Realtime Database.
- AI Hero Section Content Tool: Utilize a generative AI tool to suggest engaging, cinematic imagery concepts and descriptive text prompts for the storefront's hero section.

## Style Guidelines:

- The primary color is a rich, subdued copper (#DD8C3C), chosen to evoke warmth and elegance against the dark theme without being overly bright, drawing inspiration from candlelight and polished metal.
- The background color is a deep, warm dark grey-brown (#251F18), providing a sophisticated 'flint' like foundation that enhances contrast and embodies a professional, dark aesthetic. Its hue subtly aligns with the primary color.
- An accent color of a muted rosy red (#DB7070) will be used to highlight interactive elements and draw attention, offering an analogous yet contrasting warmth to the primary copper on the dark backdrop.
- Headline font: 'Playfair' (serif) for an elegant, high-contrast, and cinematic feel suitable for product titles and hero text. Body font: 'PT Sans' (sans-serif) for clean readability and a modern, professional appearance throughout the site.
- Use minimalist, outline-style icons to maintain a sleek and professional aesthetic, ensuring they are easily discernible against the dark background.
- Implement a 'Glassmorphism' style for product grids, offering a modern, semi-transparent frosted glass effect that subtly interacts with the dark background. Ensure all layouts are mobile-responsive using Tailwind CSS utilities.
- Incorporate subtle hover effects and transition animations, particularly for product cards and navigation elements, to provide a polished and interactive user experience without distracting from content.