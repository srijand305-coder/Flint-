import { db } from "@workspace/db";
import { productsTable, reviewsTable } from "@workspace/db/schema";

const products = [
  {
    name: "Amber Glow Soy Candle",
    description: "A warm, captivating blend of amber, sandalwood, and a hint of vanilla. Hand-poured in small batches using 100% natural soy wax for a clean, long-lasting burn of up to 45 hours.",
    price: "449",
    imageUrl: "/images/amber-glow.png",
    category: "Signature",
    inStock: true,
  },
  {
    name: "Rose & Lavender Dreams",
    description: "Delicate notes of fresh rose petals and calming lavender that create a serene, romantic atmosphere. Perfect for self-care evenings. Burns for 40 hours.",
    price: "399",
    imageUrl: "/images/rose-lavender.png",
    category: "Floral",
    inStock: true,
  },
  {
    name: "Sandalwood & Cedar Forest",
    description: "Earthy, grounding scent of warm sandalwood and forest cedar. Inspired by misty mountain mornings. Handcrafted in a rustic terracotta vessel. Burns 50 hours.",
    price: "549",
    imageUrl: "/images/sandalwood-cedar.png",
    category: "Earthy",
    inStock: true,
  },
  {
    name: "Vanilla Coconut Bliss",
    description: "Indulgent and creamy blend of Madagascar vanilla and tropical coconut milk. Comes in a premium marble-white vessel with a gold lid. Burns 35 hours.",
    price: "499",
    imageUrl: "/images/vanilla-coconut.png",
    category: "Gourmand",
    inStock: true,
  },
  {
    name: "Midnight Musk & Oud",
    description: "A deep, mysterious fragrance of dark musk and rare oud wood. For those who love bold, luxurious scents. This limited-edition black vessel is a statement piece. Burns 55 hours.",
    price: "749",
    imageUrl: "/images/midnight-musk.png",
    category: "Signature",
    inStock: true,
  },
  {
    name: "Citrus & Fresh Mint",
    description: "An energising blend of zesty orange, lemon, and cooling mint leaves. Perfect for workspaces and kitchens to keep the air fresh and uplifting. Burns 30 hours.",
    price: "299",
    imageUrl: "/images/citrus-mint.png",
    category: "Fresh",
    inStock: true,
  },
  {
    name: "Starter Soy Candle",
    description: "Our simplest, most affordable candle — pure unscented natural soy wax. Perfect for those new to artisan candles or as a base for your own fragrance experiments. Burns 25 hours.",
    price: "125",
    imageUrl: "/images/placeholder-candle.png",
    category: "Essential",
    inStock: true,
  },
];

const seedReviews = [
  {
    customerName: "Priya S.",
    productId: 1,
    productName: "Amber Glow Soy Candle",
    rating: 5,
    comment: "The scent is absolutely gorgeous! My entire room smells amazing. Will definitely order again!",
  },
  {
    customerName: "Rahul M.",
    productId: 2,
    productName: "Rose & Lavender Dreams",
    rating: 5,
    comment: "Bought this for my wife and she loves it. The packaging is beautiful too. Top quality!",
  },
  {
    customerName: "Ananya K.",
    productId: 3,
    productName: "Sandalwood & Cedar Forest",
    rating: 4,
    comment: "Very earthy and grounding. Perfect for meditation. Lasts a long time too.",
  },
];

async function seed() {
  console.log("Seeding products...");
  
  const existing = await db.select().from(productsTable);
  if (existing.length > 0) {
    console.log("Products already seeded, skipping.");
  } else {
    for (const product of products) {
      await db.insert(productsTable).values(product);
    }
    console.log(`Inserted ${products.length} products`);
  }

  const existingReviews = await db.select().from(reviewsTable);
  if (existingReviews.length > 0) {
    console.log("Reviews already seeded, skipping.");
  } else {
    for (const review of seedReviews) {
      await db.insert(reviewsTable).values(review);
    }
    console.log(`Inserted ${seedReviews.length} reviews`);
  }

  console.log("Done!");
  process.exit(0);
}

seed().catch(err => {
  console.error(err);
  process.exit(1);
});
