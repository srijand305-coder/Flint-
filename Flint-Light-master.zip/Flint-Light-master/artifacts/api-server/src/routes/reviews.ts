import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { reviewsTable, productsTable, bannedUsersTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { CreateReviewBody, DeleteReviewParams } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/reviews", async (req, res) => {
  try {
    const reviews = await db.select().from(reviewsTable).orderBy(reviewsTable.createdAt);
    const mapped = reviews.map(r => ({
      ...r,
      createdAt: r.createdAt.toISOString(),
    }));
    res.json(mapped);
  } catch (err) {
    req.log.error({ err }, "Failed to list reviews");
    res.status(500).json({ error: "Failed to list reviews" });
  }
});

router.post("/reviews", async (req, res) => {
  try {
    const body = CreateReviewBody.parse(req.body);

    const [banned] = await db.select().from(bannedUsersTable).where(eq(bannedUsersTable.customerName, body.customerName));
    if (banned) {
      return res.status(403).json({ error: "You have been banned from submitting reviews." });
    }

    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, body.productId));
    if (!product) return res.status(400).json({ error: "Product not found" });

    const [review] = await db.insert(reviewsTable).values({
      customerName: body.customerName,
      productId: body.productId,
      productName: product.name,
      rating: body.rating,
      comment: body.comment,
    }).returning();

    res.status(201).json({ ...review, createdAt: review.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to create review");
    res.status(500).json({ error: "Failed to create review" });
  }
});

router.delete("/reviews/:id", async (req, res) => {
  try {
    const { id } = DeleteReviewParams.parse({ id: req.params.id });
    await db.delete(reviewsTable).where(eq(reviewsTable.id, id));
    res.json({ success: true });
  } catch (err) {
    req.log.error({ err }, "Failed to delete review");
    res.status(500).json({ error: "Failed to delete review" });
  }
});

export default router;
