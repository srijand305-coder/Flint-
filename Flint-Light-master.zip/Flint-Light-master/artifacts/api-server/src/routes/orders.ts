import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { productsTable, ordersTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { CreateOrderBody, GetOrderParams, DeleteOrderParams, UpdateOrderStatusParams, UpdateOrderStatusBody } from "@workspace/api-zod";

const router: IRouter = Router();

type SSEClient = Response;
const sseClients: Set<SSEClient> = new Set();

function notifyNewOrder(order: Record<string, unknown>) {
  const data = JSON.stringify(order);
  for (const client of sseClients) {
    try {
      client.write(`data: ${data}\n\n`);
    } catch {
      sseClients.delete(client);
    }
  }
}

router.get("/orders/stream", (req: Request, res: Response) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.flushHeaders();

  res.write(": connected\n\n");

  sseClients.add(res);

  req.on("close", () => {
    sseClients.delete(res);
  });
});

router.get("/orders", async (req, res) => {
  try {
    const orders = await db.select().from(ordersTable).orderBy(ordersTable.createdAt);
    const mapped = orders.map(o => ({
      ...o,
      totalAmount: parseFloat(o.totalAmount),
      createdAt: o.createdAt.toISOString(),
    }));
    res.json(mapped);
  } catch (err) {
    req.log.error({ err }, "Failed to list orders");
    res.status(500).json({ error: "Failed to list orders" });
  }
});

router.get("/orders/:id", async (req, res) => {
  try {
    const { id } = GetOrderParams.parse({ id: req.params.id });
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, id));
    if (!order) return res.status(404).json({ error: "Order not found" });
    res.json({ ...order, totalAmount: parseFloat(order.totalAmount), createdAt: order.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to get order");
    res.status(500).json({ error: "Failed to get order" });
  }
});

router.post("/orders", async (req, res) => {
  try {
    const body = CreateOrderBody.parse(req.body);

    let totalAmount = 0;
    const items: Array<{productId: number; productName: string; quantity: number; price: number}> = [];

    for (const item of body.items) {
      const [product] = await db.select().from(productsTable).where(eq(productsTable.id, item.productId));
      if (!product) {
        return res.status(400).json({ error: `Product ${item.productId} not found` });
      }
      const price = parseFloat(product.price);
      totalAmount += price * item.quantity;
      items.push({
        productId: product.id,
        productName: product.name,
        quantity: item.quantity,
        price,
      });
    }

    const [order] = await db.insert(ordersTable).values({
      customerName: body.customerName,
      customerEmail: body.customerEmail,
      customerPhone: body.customerPhone,
      address: body.address,
      city: body.city,
      pincode: body.pincode,
      items,
      totalAmount: String(totalAmount),
      status: "pending",
    }).returning();

    const orderResponse = {
      ...order,
      totalAmount: parseFloat(order.totalAmount),
      createdAt: order.createdAt.toISOString(),
    };

    notifyNewOrder(orderResponse as unknown as Record<string, unknown>);

    res.status(201).json(orderResponse);
  } catch (err) {
    req.log.error({ err }, "Failed to create order");
    res.status(500).json({ error: "Failed to create order" });
  }
});

router.delete("/orders/:id", async (req, res) => {
  try {
    const { id } = DeleteOrderParams.parse({ id: req.params.id });
    await db.delete(ordersTable).where(eq(ordersTable.id, id));
    res.json({ success: true });
  } catch (err) {
    req.log.error({ err }, "Failed to delete order");
    res.status(500).json({ error: "Failed to delete order" });
  }
});

router.patch("/orders/:id/status", async (req, res) => {
  try {
    const { id } = UpdateOrderStatusParams.parse({ id: req.params.id });
    const { status } = UpdateOrderStatusBody.parse(req.body);
    const [order] = await db.update(ordersTable)
      .set({ status })
      .where(eq(ordersTable.id, id))
      .returning();
    if (!order) return res.status(404).json({ error: "Order not found" });
    res.json({ ...order, totalAmount: parseFloat(order.totalAmount), createdAt: order.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to update order status");
    res.status(500).json({ error: "Failed to update order status" });
  }
});

export default router;
