import { Router, type IRouter } from "express";
import healthRouter from "./health";
import productsRouter from "./products";
import ordersRouter from "./orders";
import reviewsRouter from "./reviews";
import bannedUsersRouter from "./banned-users";

const router: IRouter = Router();

router.use(healthRouter);
router.use(productsRouter);
router.use(ordersRouter);
router.use(reviewsRouter);
router.use(bannedUsersRouter);

export default router;
