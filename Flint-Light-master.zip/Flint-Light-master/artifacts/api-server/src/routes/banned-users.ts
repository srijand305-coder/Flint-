import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { bannedUsersTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";

const router: IRouter = Router();

router.get("/banned-users", async (req, res) => {
  try {
    const banned = await db.select().from(bannedUsersTable).orderBy(bannedUsersTable.bannedAt);
    const mapped = banned.map(b => ({ ...b, bannedAt: b.bannedAt.toISOString() }));
    res.json(mapped);
  } catch (err) {
    req.log.error({ err }, "Failed to list banned users");
    res.status(500).json({ error: "Failed to list banned users" });
  }
});

router.post("/banned-users", async (req, res) => {
  try {
    const { customerName, reason } = req.body as { customerName?: string; reason?: string };
    if (!customerName || typeof customerName !== "string" || customerName.trim() === "") {
      return res.status(400).json({ error: "customerName is required" });
    }
    const [existing] = await db.select().from(bannedUsersTable).where(eq(bannedUsersTable.customerName, customerName.trim()));
    if (existing) {
      return res.status(409).json({ error: "User is already banned" });
    }
    const [banned] = await db.insert(bannedUsersTable).values({
      customerName: customerName.trim(),
      reason: reason?.trim() || null,
    }).returning();
    res.status(201).json({ ...banned, bannedAt: banned.bannedAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to ban user");
    res.status(500).json({ error: "Failed to ban user" });
  }
});

router.delete("/banned-users/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
    await db.delete(bannedUsersTable).where(eq(bannedUsersTable.id, id));
    res.json({ success: true });
  } catch (err) {
    req.log.error({ err }, "Failed to unban user");
    res.status(500).json({ error: "Failed to unban user" });
  }
});

export default router;
