import { useEffect, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { getListOrdersQueryKey } from '@workspace/api-client-react';

export function useOrderStream() {
  const [newOrderAlert, setNewOrderAlert] = useState<string | null>(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    // Only connect to SSE when the hook is mounted (e.g. on Dashboard)
    const es = new EventSource('/api/orders/stream');
    
    es.onmessage = (event) => {
      try {
        // Simple ping/heartbeat ignore
        if (event.data === 'ping') return;
        
        setNewOrderAlert(event.data);
        
        // Invalidate the orders list to automatically fetch the new data
        queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() });
        
        // Clear alert after 5 seconds to allow it to trigger again
        setTimeout(() => setNewOrderAlert(null), 5000);
      } catch (err) {
        console.error("Error processing SSE message", err);
      }
    };

    es.onerror = () => {
      console.error("SSE connection error");
      es.close();
    };

    return () => {
      es.close();
    };
  }, [queryClient]);

  return newOrderAlert;
}
