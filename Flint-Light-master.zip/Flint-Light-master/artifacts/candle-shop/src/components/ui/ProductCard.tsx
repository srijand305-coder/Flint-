import { Link } from "wouter";
import { type Product } from "@workspace/api-client-react";
import { useCart } from "@/store/use-cart";
import { ShoppingBag } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

interface ProductCardProps {
  product: Product;
  index?: number;
}

export function ProductCard({ product, index = 0 }: ProductCardProps) {
  const addItem = useCart((state) => state.addItem);
  const { toast } = useToast();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent navigating when clicking the button
    addItem(product, 1);
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    });
  };

  const imageSrc = product.imageUrl || `${import.meta.env.BASE_URL}images/placeholder-candle.png`;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group"
    >
      <Link href={`/product/${product.id}`} className="block relative bg-card rounded-xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-border/50">
        <div className="aspect-[4/5] overflow-hidden bg-secondary relative">
          <img 
            src={imageSrc} 
            alt={product.name} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
            onError={(e) => {
              (e.target as HTMLImageElement).src = `${import.meta.env.BASE_URL}images/placeholder-candle.png`;
            }}
          />
          {!product.inStock && (
            <div className="absolute top-4 left-4 bg-background/90 backdrop-blur text-foreground px-3 py-1 text-xs font-bold tracking-wider uppercase rounded-full">
              Sold Out
            </div>
          )}
          
          <div className="absolute bottom-4 left-0 right-0 px-4 opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
            <button
              onClick={handleAddToCart}
              disabled={!product.inStock}
              className="w-full py-3 bg-primary/90 hover:bg-primary text-primary-foreground backdrop-blur-sm rounded-lg font-semibold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
            >
              <ShoppingBag className="w-4 h-4" />
              Add to Cart
            </button>
          </div>
        </div>
        
        <div className="p-5 text-center">
          <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">{product.category}</p>
          <h3 className="font-display font-medium text-xl text-foreground mb-2 group-hover:text-primary transition-colors">{product.name}</h3>
          <p className="text-lg font-semibold text-primary">₹{product.price.toLocaleString()}</p>
        </div>
      </Link>
    </motion.div>
  );
}
