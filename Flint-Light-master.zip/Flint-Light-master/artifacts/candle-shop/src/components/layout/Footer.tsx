import { Link } from "wouter";
import { Instagram, Facebook, Twitter, Mail, MapPin } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-foreground text-secondary pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-1">
              <img
                src={`${import.meta.env.BASE_URL}images/logo.png`}
                alt="Flint & Light"
                className="h-10 w-10 object-contain brightness-0 invert"
              />
              <div>
                <span className="font-display font-bold text-2xl tracking-wide text-white block leading-tight">
                  Flint & Light
                </span>
                <span className="text-[9px] tracking-[0.18em] text-primary/80 uppercase font-medium">
                  Subtle Flame · Lasting Presence
                </span>
              </div>
            </Link>
            <p className="text-muted-foreground max-w-sm mb-6 leading-relaxed mt-4">
              Artisan candles hand-poured with love. Illuminating your space with warmth, luxury, and captivating fragrances.
            </p>
            <div className="flex gap-4 mb-6">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors"><Instagram className="w-5 h-5" /></a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors"><Facebook className="w-5 h-5" /></a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors"><Twitter className="w-5 h-5" /></a>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-muted-foreground text-sm">
                <Mail className="w-4 h-4 text-primary flex-shrink-0" />
                <a href="mailto:flintandlight@gmail.com" className="hover:text-primary transition-colors">
                  flintandlight@gmail.com
                </a>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground text-sm">
                <MapPin className="w-4 h-4 text-primary flex-shrink-0" />
                <span>India</span>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="font-display font-semibold text-lg text-white mb-4">Shop</h3>
            <ul className="space-y-3">
              <li><Link href="/shop" className="text-muted-foreground hover:text-primary transition-colors">All Candles</Link></li>
              <li><Link href="/shop" className="text-muted-foreground hover:text-primary transition-colors">Best Sellers</Link></li>
              <li><Link href="/shop" className="text-muted-foreground hover:text-primary transition-colors">New Arrivals</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-display font-semibold text-lg text-white mb-4">Support</h3>
            <ul className="space-y-3">
              <li><Link href="/reviews" className="text-muted-foreground hover:text-primary transition-colors">Customer Reviews</Link></li>
              <li><a href="mailto:flintandlight@gmail.com" className="text-muted-foreground hover:text-primary transition-colors">Contact Us</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Shipping & Returns</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Flint and Light Candles. All rights reserved.
          </p>
          <div className="flex gap-4 text-sm text-muted-foreground">
            <a href="#" className="hover:text-primary">Privacy Policy</a>
            <a href="#" className="hover:text-primary">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
