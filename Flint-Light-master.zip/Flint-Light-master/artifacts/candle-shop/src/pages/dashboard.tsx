import { useState } from "react";
import { Link } from "wouter";
import { 
  useListOrders, useUpdateOrderStatus, useDeleteOrder,
  useListProducts, useCreateProduct, useDeleteProduct,
  useListReviews, useDeleteReview 
} from "@workspace/api-client-react";
import { useOrderStream } from "@/hooks/use-order-stream";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { Flame, Package, ShoppingBag, Star, TrendingUp, Plus, Trash2, Home, Activity } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const productSchema = z.object({
  name: z.string().min(2),
  description: z.string().min(10),
  price: z.coerce.number().min(1),
  imageUrl: z.string().url(),
  category: z.string().min(2),
  inStock: z.boolean().default(true),
});

type ProductForm = z.infer<typeof productSchema>;

export function Dashboard() {
  const [activeTab, setActiveTab] = useState<"orders" | "products" | "reviews">("orders");
  const [isAddProductOpen, setIsAddProductOpen] = useState(false);
  
  const { toast } = useToast();
  
  // Real-time order listener
  const newOrder = useOrderStream();
  if (newOrder) {
    // This will trigger a small visual indicator or toast automatically via the hook, 
    // but the query invalidation handles the UI update.
  }

  const { data: orders, refetch: refetchOrders } = useListOrders();
  const { data: products, refetch: refetchProducts } = useListProducts();
  const { data: reviews, refetch: refetchReviews } = useListReviews();

  const { mutate: updateStatus } = useUpdateOrderStatus({ onSuccess: () => refetchOrders() });
  const { mutate: deleteOrder } = useDeleteOrder({ onSuccess: () => refetchOrders() });
  const { mutate: deleteProduct } = useDeleteProduct({ onSuccess: () => refetchProducts() });
  const { mutate: deleteReview } = useDeleteReview({ onSuccess: () => refetchReviews() });
  
  const { mutate: createProduct, isPending: isAddingProduct } = useCreateProduct({
    mutation: {
      onSuccess: () => {
        toast({ title: "Product added!" });
        setIsAddProductOpen(false);
        resetProductForm();
        refetchProducts();
      }
    }
  });

  const { register, handleSubmit, reset: resetProductForm, formState: { errors } } = useForm<ProductForm>({
    resolver: zodResolver(productSchema),
    defaultValues: { inStock: true }
  });

  const onSubmitProduct = (data: ProductForm) => createProduct({ data });

  // Stats calculation
  const totalRevenue = orders?.filter(o => o.status !== "cancelled").reduce((sum, o) => sum + o.totalAmount, 0) || 0;
  const avgRating = reviews?.length ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1) : "0.0";

  return (
    <div className="min-h-screen bg-secondary flex">
      
      {/* Sidebar */}
      <aside className="w-64 bg-card border-r border-border hidden md:flex flex-col">
        <div className="p-6 border-b border-border">
          <Link href="/" className="flex items-center gap-2 group">
            <Flame className="w-6 h-6 text-primary group-hover:scale-110 transition-transform" />
            <span className="font-display font-bold text-xl tracking-wide">Owner Portal</span>
          </Link>
        </div>
        <nav className="p-4 space-y-2 flex-grow">
          <button 
            onClick={() => setActiveTab("orders")}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-colors ${activeTab === "orders" ? "bg-primary text-primary-foreground" : "hover:bg-secondary text-muted-foreground hover:text-foreground"}`}
          >
            <ShoppingBag className="w-5 h-5" /> Orders
          </button>
          <button 
            onClick={() => setActiveTab("products")}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-colors ${activeTab === "products" ? "bg-primary text-primary-foreground" : "hover:bg-secondary text-muted-foreground hover:text-foreground"}`}
          >
            <Package className="w-5 h-5" /> Products
          </button>
          <button 
            onClick={() => setActiveTab("reviews")}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-colors ${activeTab === "reviews" ? "bg-primary text-primary-foreground" : "hover:bg-secondary text-muted-foreground hover:text-foreground"}`}
          >
            <Star className="w-5 h-5" /> Reviews
          </button>
        </nav>
        <div className="p-4 border-t border-border">
          <Link href="/" className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-secondary rounded-xl font-medium text-foreground hover:bg-border transition-colors">
            <Home className="w-4 h-4" /> Back to Store
          </Link>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow p-4 md:p-8 overflow-y-auto">
        
        {/* Top Header & Stats */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <h1 className="font-display text-4xl font-bold text-foreground capitalize">{activeTab}</h1>
            {newOrder && (
              <div className="flex items-center gap-2 bg-accent/20 text-accent px-4 py-2 rounded-full text-sm font-bold animate-pulse">
                <Activity className="w-4 h-4" /> New Order Received!
              </div>
            )}
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-card p-6 rounded-2xl border border-border shadow-sm">
              <p className="text-muted-foreground text-sm font-semibold mb-1">Total Revenue</p>
              <p className="text-3xl font-display font-bold text-primary">₹{totalRevenue.toLocaleString()}</p>
            </div>
            <div className="bg-card p-6 rounded-2xl border border-border shadow-sm">
              <p className="text-muted-foreground text-sm font-semibold mb-1">Total Orders</p>
              <p className="text-3xl font-display font-bold">{orders?.length || 0}</p>
            </div>
            <div className="bg-card p-6 rounded-2xl border border-border shadow-sm">
              <p className="text-muted-foreground text-sm font-semibold mb-1">Products</p>
              <p className="text-3xl font-display font-bold">{products?.length || 0}</p>
            </div>
            <div className="bg-card p-6 rounded-2xl border border-border shadow-sm">
              <p className="text-muted-foreground text-sm font-semibold mb-1">Average Rating</p>
              <div className="flex items-center gap-2">
                <p className="text-3xl font-display font-bold">{avgRating}</p>
                <Star className="w-5 h-5 fill-primary text-primary" />
              </div>
            </div>
          </div>
        </div>

        {/* Tab Content */}
        <div className="bg-card rounded-2xl border border-border shadow-sm overflow-hidden min-h-[500px]">
          
          {/* ORDERS TAB */}
          {activeTab === "orders" && (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-secondary/50 text-muted-foreground text-sm uppercase tracking-wider">
                    <th className="p-4 font-semibold">Order ID</th>
                    <th className="p-4 font-semibold">Customer</th>
                    <th className="p-4 font-semibold">Date</th>
                    <th className="p-4 font-semibold">Total</th>
                    <th className="p-4 font-semibold">Status</th>
                    <th className="p-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {orders?.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(order => (
                    <tr key={order.id} className="hover:bg-secondary/20 transition-colors">
                      <td className="p-4 font-medium">#{order.id.toString().padStart(4, '0')}</td>
                      <td className="p-4">
                        <p className="font-semibold text-foreground">{order.customerName}</p>
                        <p className="text-xs text-muted-foreground">{order.city}, {order.pincode}</p>
                      </td>
                      <td className="p-4 text-sm text-muted-foreground">{format(new Date(order.createdAt), 'MMM d, yyyy')}</td>
                      <td className="p-4 font-semibold">₹{order.totalAmount.toLocaleString()}</td>
                      <td className="p-4">
                        <select 
                          value={order.status}
                          onChange={(e) => updateStatus({ id: order.id, data: { status: e.target.value as any }})}
                          className={`text-xs font-bold px-3 py-1 rounded-full border outline-none ${
                            order.status === 'delivered' ? 'bg-green-100 text-green-800 border-green-200' :
                            order.status === 'cancelled' ? 'bg-red-100 text-red-800 border-red-200' :
                            'bg-primary/10 text-primary border-primary/20'
                          }`}
                        >
                          <option value="pending">Pending</option>
                          <option value="confirmed">Confirmed</option>
                          <option value="shipped">Shipped</option>
                          <option value="delivered">Delivered</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </td>
                      <td className="p-4 text-right">
                        <button onClick={() => {
                          if (confirm('Delete this order?')) deleteOrder({ id: order.id });
                        }} className="p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {orders?.length === 0 && (
                    <tr><td colSpan={6} className="p-8 text-center text-muted-foreground">No orders found.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* PRODUCTS TAB */}
          {activeTab === "products" && (
            <div>
              <div className="p-4 border-b border-border flex justify-end">
                <button 
                  onClick={() => setIsAddProductOpen(true)}
                  className="px-4 py-2 bg-primary text-primary-foreground rounded-lg font-semibold flex items-center gap-2 hover:bg-primary/90 transition-colors"
                >
                  <Plus className="w-4 h-4" /> Add Product
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-secondary/50 text-muted-foreground text-sm uppercase tracking-wider">
                      <th className="p-4 font-semibold">Product</th>
                      <th className="p-4 font-semibold">Category</th>
                      <th className="p-4 font-semibold">Price</th>
                      <th className="p-4 font-semibold">Stock</th>
                      <th className="p-4 font-semibold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {products?.map(product => (
                      <tr key={product.id} className="hover:bg-secondary/20 transition-colors">
                        <td className="p-4 flex items-center gap-3">
                          <img src={product.imageUrl} alt={product.name} className="w-10 h-10 rounded object-cover border border-border" />
                          <span className="font-semibold">{product.name}</span>
                        </td>
                        <td className="p-4 text-sm">{product.category}</td>
                        <td className="p-4 font-semibold">₹{product.price.toLocaleString()}</td>
                        <td className="p-4">
                          <span className={`px-2 py-1 rounded text-xs font-bold ${product.inStock ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                            {product.inStock ? 'In Stock' : 'Out of Stock'}
                          </span>
                        </td>
                        <td className="p-4 text-right">
                          <button onClick={() => {
                            if (confirm('Delete this product?')) deleteProduct({ id: product.id });
                          }} className="p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive rounded-lg transition-colors">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* REVIEWS TAB */}
          {activeTab === "reviews" && (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-secondary/50 text-muted-foreground text-sm uppercase tracking-wider">
                    <th className="p-4 font-semibold">Customer</th>
                    <th className="p-4 font-semibold">Product</th>
                    <th className="p-4 font-semibold">Rating</th>
                    <th className="p-4 font-semibold">Comment</th>
                    <th className="p-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {reviews?.map(review => (
                    <tr key={review.id} className="hover:bg-secondary/20 transition-colors">
                      <td className="p-4 font-medium">{review.customerName}</td>
                      <td className="p-4 text-sm">{review.productName}</td>
                      <td className="p-4">
                        <div className="flex text-primary">
                          {[...Array(review.rating)].map((_, i) => <Star key={i} className="w-3 h-3 fill-current" />)}
                        </div>
                      </td>
                      <td className="p-4 text-sm max-w-xs truncate">{review.comment}</td>
                      <td className="p-4 text-right">
                        <button onClick={() => {
                          if (confirm('Delete this review?')) deleteReview({ id: review.id });
                        }} className="p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>

      {/* Add Product Modal */}
      <AnimatePresence>
        {isAddProductOpen && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/50 backdrop-blur-sm p-4"
          >
            <motion.div 
              initial={{ scale: 0.95 }} animate={{ scale: 1 }} exit={{ scale: 0.95 }}
              className="bg-card w-full max-w-lg rounded-2xl shadow-xl border border-border p-6 overflow-y-auto max-h-[90vh]"
            >
              <h2 className="font-display text-2xl font-bold mb-6">Add New Product</h2>
              <form onSubmit={handleSubmit(onSubmitProduct)} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Name</label>
                  <input {...register("name")} className="w-full px-4 py-2 rounded-xl border border-border focus:border-primary outline-none" />
                  {errors.name && <span className="text-destructive text-xs">{errors.name.message}</span>}
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Description</label>
                  <textarea {...register("description")} rows={3} className="w-full px-4 py-2 rounded-xl border border-border focus:border-primary outline-none resize-none" />
                  {errors.description && <span className="text-destructive text-xs">{errors.description.message}</span>}
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Price (₹)</label>
                    <input type="number" {...register("price")} className="w-full px-4 py-2 rounded-xl border border-border focus:border-primary outline-none" />
                    {errors.price && <span className="text-destructive text-xs">{errors.price.message}</span>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Category</label>
                    <input {...register("category")} className="w-full px-4 py-2 rounded-xl border border-border focus:border-primary outline-none" placeholder="e.g. Floral, Earthy" />
                    {errors.category && <span className="text-destructive text-xs">{errors.category.message}</span>}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Image URL</label>
                  <input {...register("imageUrl")} className="w-full px-4 py-2 rounded-xl border border-border focus:border-primary outline-none" placeholder="https://..." />
                  {errors.imageUrl && <span className="text-destructive text-xs">{errors.imageUrl.message}</span>}
                </div>
                <div className="flex items-center gap-2 pt-2">
                  <input type="checkbox" id="inStock" {...register("inStock")} className="w-4 h-4 text-primary rounded border-border" />
                  <label htmlFor="inStock" className="text-sm font-medium">In Stock</label>
                </div>
                
                <div className="flex gap-4 pt-6">
                  <button type="button" onClick={() => setIsAddProductOpen(false)} className="flex-1 py-3 bg-secondary rounded-xl font-bold text-foreground">Cancel</button>
                  <button type="submit" disabled={isAddingProduct} className="flex-1 py-3 bg-primary text-primary-foreground rounded-xl font-bold flex justify-center items-center gap-2">
                    {isAddingProduct ? "Saving..." : "Save Product"}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
