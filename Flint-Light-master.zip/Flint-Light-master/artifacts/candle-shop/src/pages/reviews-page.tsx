import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { useListProducts, useCreateReview, useListReviews } from "@workspace/api-client-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Star, Loader2 } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";

const reviewSchema = z.object({
  customerName: z.string().min(2, "Name is required"),
  productId: z.coerce.number().min(1, "Please select a product"),
  rating: z.number().min(1, "Rating is required").max(5),
  comment: z.string().min(10, "Please write a slightly longer review"),
});

type ReviewForm = z.infer<typeof reviewSchema>;

export function ReviewsPage() {
  const { data: products } = useListProducts();
  const { data: reviews, refetch } = useListReviews();
  const { toast } = useToast();
  
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);

  const { mutate: createReview, isPending } = useCreateReview({
    mutation: {
      onSuccess: () => {
        toast({ title: "Review submitted", description: "Thank you for your feedback!" });
        reset();
        setRating(0);
        refetch();
      },
      onError: (error: unknown) => {
        const status = (error as { status?: number })?.status;
        if (status === 403) {
          toast({
            title: "Unable to submit review",
            description: "Your account has been restricted from submitting reviews.",
            variant: "destructive",
          });
        } else {
          toast({ title: "Error", description: "Failed to submit review. Please try again.", variant: "destructive" });
        }
      }
    }
  });

  const { register, handleSubmit, setValue, reset, formState: { errors } } = useForm<ReviewForm>({
    resolver: zodResolver(reviewSchema),
    defaultValues: { rating: 0 }
  });

  const onSubmit = (data: ReviewForm) => {
    createReview({ data });
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-32 pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-3 gap-16">
          
          {/* Write a Review Form */}
          <div className="lg:col-span-1">
            <div className="bg-card p-8 rounded-2xl shadow-sm border border-border sticky top-32">
              <h2 className="font-display text-3xl font-bold mb-2">Write a Review</h2>
              <p className="text-muted-foreground mb-8">Share your experience with Flint & Light candles.</p>
              
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
                <div>
                  <label className="block text-sm font-medium mb-1">Your Name</label>
                  <input 
                    {...register("customerName")}
                    className="w-full px-4 py-3 rounded-xl bg-background border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all" 
                    placeholder="Jane Doe"
                  />
                  {errors.customerName && <p className="text-destructive text-sm mt-1">{errors.customerName.message}</p>}
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Product</label>
                  <select 
                    {...register("productId")}
                    className="w-full px-4 py-3 rounded-xl bg-background border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                  >
                    <option value="">Select a candle...</option>
                    {products?.map(p => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                  {errors.productId && <p className="text-destructive text-sm mt-1">{errors.productId.message}</p>}
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Rating</label>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => { setRating(star); setValue("rating", star); }}
                        onMouseEnter={() => setHoverRating(star)}
                        onMouseLeave={() => setHoverRating(0)}
                        className="p-1 focus:outline-none"
                      >
                        <Star 
                          className={`w-8 h-8 transition-all ${
                            star <= (hoverRating || rating) 
                              ? "fill-primary text-primary" 
                              : "text-border fill-transparent"
                          }`} 
                        />
                      </button>
                    ))}
                  </div>
                  {errors.rating && <p className="text-destructive text-sm mt-1">{errors.rating.message}</p>}
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Your Review</label>
                  <textarea 
                    {...register("comment")}
                    rows={4}
                    className="w-full px-4 py-3 rounded-xl bg-background border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all resize-none" 
                    placeholder="Tell us what you loved about it..."
                  />
                  {errors.comment && <p className="text-destructive text-sm mt-1">{errors.comment.message}</p>}
                </div>
                
                <button 
                  type="submit"
                  disabled={isPending}
                  className="w-full py-4 bg-primary text-primary-foreground rounded-xl font-bold shadow-md hover:bg-primary/90 transition-all flex justify-center items-center gap-2"
                >
                  {isPending && <Loader2 className="w-5 h-5 animate-spin" />}
                  Submit Review
                </button>
              </form>
            </div>
          </div>
          
          {/* Read Reviews */}
          <div className="lg:col-span-2">
            <h2 className="font-display text-4xl font-bold mb-8">Latest Community Love</h2>
            
            {reviews?.length === 0 ? (
              <div className="p-12 text-center bg-card rounded-2xl border border-dashed border-border text-muted-foreground">
                No reviews yet. Be the first to share your thoughts!
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {reviews?.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(review => (
                  <div key={review.id} className="bg-card p-6 rounded-2xl shadow-sm border border-border/50 flex flex-col">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex text-primary">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className={`w-4 h-4 ${i < review.rating ? "fill-current" : "text-border"}`} />
                        ))}
                      </div>
                      <span className="text-xs text-muted-foreground">{format(new Date(review.createdAt), 'MMM d, yyyy')}</span>
                    </div>
                    <p className="text-foreground/80 leading-relaxed mb-4 flex-grow italic">"{review.comment}"</p>
                    <div className="pt-4 border-t border-border/50">
                      <p className="font-bold text-sm text-foreground">{review.customerName}</p>
                      <p className="text-xs text-muted-foreground">on <span className="text-primary font-medium">{review.productName}</span></p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
