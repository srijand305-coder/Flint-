import { useParams, Link } from "wouter";
import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { useGetProduct, useListReviews } from "@workspace/api-client-react";
import { useCart } from "@/store/use-cart";
import { useToast } from "@/hooks/use-toast";
import { Minus, Plus, ShoppingBag, ArrowLeft, Star } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";

export function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const productId = parseInt(id || "0", 10);
  
  const { data: product, isLoading } = useGetProduct(productId);
  const { data: allReviews } = useListReviews();
  
  const productReviews = allReviews?.filter(r => r.productId === productId) || [];
  const avgRating = productReviews.length > 0 
    ? productReviews.reduce((sum, r) => sum + r.rating, 0) / productReviews.length 
    : 0;
  
  const [quantity, setQuantity] = useState(1);
  const addItem = useCart(state => state.addItem);
  const { toast } = useToast();

  const handleAddToCart = () => {
    if (product) {
      addItem(product, quantity);
      toast({
        title: "Added to cart",
        description: `${quantity}x ${product.name} added to your cart.`,
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <main className="flex-grow pt-32 flex justify-center items-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
        </main>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <main className="flex-grow pt-32 text-center">
          <h1 className="text-2xl font-bold mb-4">Product not found</h1>
          <Link href="/shop" className="text-primary hover:underline">Return to shop</Link>
        </main>
      </div>
    );
  }

  const imageSrc = product.imageUrl || `${import.meta.env.BASE_URL}images/placeholder-candle.png`;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-32 pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <Link href="/shop" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors">
            <ArrowLeft className="w-4 h-4" /> Back to Shop
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24">
            {/* Product Image */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-secondary rounded-2xl overflow-hidden shadow-lg aspect-square lg:aspect-auto lg:h-[600px] relative"
            >
              <img 
                src={imageSrc} 
                alt={product.name} 
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = `${import.meta.env.BASE_URL}images/placeholder-candle.png`;
                }}
              />
            </motion.div>

            {/* Product Info */}
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex flex-col justify-center"
            >
              <div className="mb-2">
                <span className="text-primary font-bold tracking-widest uppercase text-xs">
                  {product.category}
                </span>
              </div>
              
              <h1 className="font-display text-4xl lg:text-5xl font-bold text-foreground mb-4">
                {product.name}
              </h1>
              
              <div className="flex items-center gap-4 mb-6">
                <p className="text-2xl font-semibold text-primary">₹{product.price.toLocaleString()}</p>
                {productReviews.length > 0 && (
                  <div className="flex items-center gap-1 bg-secondary px-3 py-1 rounded-full text-sm">
                    <Star className="w-4 h-4 fill-primary text-primary" />
                    <span className="font-semibold">{avgRating.toFixed(1)}</span>
                    <span className="text-muted-foreground">({productReviews.length})</span>
                  </div>
                )}
              </div>
              
              <p className="text-lg text-muted-foreground leading-relaxed mb-8">
                {product.description}
              </p>
              
              <div className="border-y border-border py-8 mb-8">
                <div className="flex items-center gap-6">
                  <div className="flex items-center bg-card border border-border rounded-full p-1 shadow-sm">
                    <button 
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-secondary transition-colors"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-12 text-center font-semibold text-lg">{quantity}</span>
                    <button 
                      onClick={() => setQuantity(quantity + 1)}
                      className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-secondary transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <button
                    onClick={handleAddToCart}
                    disabled={!product.inStock}
                    className="flex-grow py-4 bg-primary text-primary-foreground rounded-full font-semibold flex items-center justify-center gap-2 hover:bg-primary/90 hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ShoppingBag className="w-5 h-5" />
                    {product.inStock ? "Add to Cart" : "Out of Stock"}
                  </button>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                <div>
                  <strong className="text-foreground block mb-1">Burn Time</strong>
                  Approx. 45-50 Hours
                </div>
                <div>
                  <strong className="text-foreground block mb-1">Weight</strong>
                  250g / 8.8oz
                </div>
                <div>
                  <strong className="text-foreground block mb-1">Dimensions</strong>
                  3.5" W x 4" H
                </div>
                <div>
                  <strong className="text-foreground block mb-1">Materials</strong>
                  Soy Wax Blend, Cotton Wick
                </div>
              </div>
            </motion.div>
          </div>
          
          {/* Reviews Section */}
          <div className="mt-32">
            <div className="flex justify-between items-end mb-12 border-b border-border pb-6">
              <h2 className="font-display text-3xl font-bold">Customer Reviews</h2>
              <Link href="/reviews" className="text-primary font-semibold hover:underline">Write a Review</Link>
            </div>
            
            {productReviews.length === 0 ? (
              <p className="text-muted-foreground italic">No reviews yet for this product. Be the first!</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {productReviews.map(review => (
                  <div key={review.id} className="bg-card p-6 rounded-2xl shadow-sm border border-border/50">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h4 className="font-bold text-foreground">{review.customerName}</h4>
                        <span className="text-xs text-muted-foreground">{format(new Date(review.createdAt), 'MMM d, yyyy')}</span>
                      </div>
                      <div className="flex text-primary">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className={`w-4 h-4 ${i < review.rating ? "fill-current" : "text-border"}`} />
                        ))}
                      </div>
                    </div>
                    <p className="text-muted-foreground leading-relaxed">"{review.comment}"</p>
                  </div>
                ))}
              </div>
            )}
          </div>
          
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
