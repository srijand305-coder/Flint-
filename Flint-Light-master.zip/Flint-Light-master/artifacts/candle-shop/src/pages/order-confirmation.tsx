import { Link } from "wouter";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";

export function OrderConfirmation() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow flex items-center justify-center py-24">
        <div className="max-w-xl w-full px-4 text-center">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", bounce: 0.5 }}
            className="w-24 h-24 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-8"
          >
            <CheckCircle2 className="w-12 h-12" />
          </motion.div>
          
          <h1 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
            Thank You for Your Order
          </h1>
          <p className="text-lg text-muted-foreground mb-8">
            Your elegant artisan candles will be illuminating your space soon. We've sent a confirmation email with your order details.
          </p>
          
          <div className="bg-card border border-border p-6 rounded-2xl mb-8 text-left max-w-sm mx-auto shadow-sm">
            <h3 className="font-bold text-lg mb-2">What's next?</h3>
            <ul className="text-muted-foreground space-y-2 text-sm">
              <li className="flex gap-2"><span>1.</span> Order confirmation email sent</li>
              <li className="flex gap-2"><span>2.</span> We hand-pack your items securely</li>
              <li className="flex gap-2"><span>3.</span> Order shipped within 24-48 hours</li>
            </ul>
          </div>
          
          <Link 
            href="/shop" 
            className="inline-block px-8 py-4 bg-primary text-primary-foreground rounded-full font-bold shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all"
          >
            Continue Shopping
          </Link>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
