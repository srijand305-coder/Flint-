import { Link } from "wouter";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { useCart } from "@/store/use-cart";
import { Trash2, Minus, Plus, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

export function Cart() {
  const { items, updateQuantity, removeItem, totalAmount } = useCart();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <h1 className="font-display text-4xl font-bold text-foreground mb-12">Your Cart</h1>
          
          {items.length === 0 ? (
            <div className="text-center py-24 bg-card rounded-2xl shadow-sm border border-border">
              <h2 className="text-2xl font-bold text-foreground mb-4">Your cart is empty</h2>
              <p className="text-muted-foreground mb-8">Looks like you haven't added any elegant candles yet.</p>
              <Link href="/shop" className="px-8 py-3 bg-primary text-primary-foreground rounded-full font-semibold hover:bg-primary/90 transition-colors">
                Continue Shopping
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
              <div className="lg:col-span-2 space-y-6">
                {items.map((item, index) => (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    key={item.product.id} 
                    className="flex flex-col sm:flex-row gap-6 bg-card p-4 rounded-2xl shadow-sm border border-border"
                  >
                    <div className="w-full sm:w-32 h-32 bg-secondary rounded-xl overflow-hidden shrink-0">
                      <img 
                        src={item.product.imageUrl || `${import.meta.env.BASE_URL}images/placeholder-candle.png`}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = `${import.meta.env.BASE_URL}images/placeholder-candle.png`;
                        }}
                      />
                    </div>
                    
                    <div className="flex-grow flex flex-col justify-between">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-xs text-primary font-bold uppercase tracking-wider mb-1">{item.product.category}</p>
                          <Link href={`/product/${item.product.id}`} className="font-display font-bold text-xl hover:text-primary transition-colors">
                            {item.product.name}
                          </Link>
                        </div>
                        <p className="font-semibold text-lg">₹{item.product.price.toLocaleString()}</p>
                      </div>
                      
                      <div className="flex justify-between items-center mt-4">
                        <div className="flex items-center bg-background border border-border rounded-full p-1">
                          <button 
                            onClick={() => updateQuantity(item.product.id, Math.max(1, item.quantity - 1))}
                            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-secondary transition-colors"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-10 text-center font-medium text-sm">{item.quantity}</span>
                          <button 
                            onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-secondary transition-colors"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        
                        <button 
                          onClick={() => removeItem(item.product.id)}
                          className="text-muted-foreground hover:text-destructive transition-colors flex items-center gap-1 text-sm font-medium"
                        >
                          <Trash2 className="w-4 h-4" /> Remove
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
              
              <div className="lg:col-span-1">
                <div className="bg-card p-8 rounded-2xl shadow-sm border border-border sticky top-32">
                  <h3 className="font-display font-bold text-2xl mb-6 border-b border-border pb-4">Order Summary</h3>
                  
                  <div className="space-y-4 mb-8">
                    <div className="flex justify-between text-muted-foreground">
                      <span>Subtotal</span>
                      <span>₹{totalAmount().toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>Shipping</span>
                      <span>Calculated at checkout</span>
                    </div>
                    <div className="border-t border-border pt-4 flex justify-between font-bold text-lg text-foreground">
                      <span>Total</span>
                      <span>₹{totalAmount().toLocaleString()}</span>
                    </div>
                  </div>
                  
                  <Link 
                    href="/checkout" 
                    className="w-full py-4 bg-primary text-primary-foreground rounded-xl font-semibold flex items-center justify-center gap-2 hover:bg-primary/90 transition-all shadow-md"
                  >
                    Proceed to Checkout <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            </div>
          )}
          
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
