import { Link } from "wouter";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { useListProducts } from "@workspace/api-client-react";
import { ProductCard } from "@/components/ui/ProductCard";
import { motion } from "framer-motion";
import { ArrowRight, Star } from "lucide-react";

export function Home() {
  const { data: products, isLoading } = useListProducts();
  
  const featuredProducts = products?.slice(0, 3) || [];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0">
            <img 
              src={`${import.meta.env.BASE_URL}images/hero-candle.png`} 
              alt="Luxurious artisan candle" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/60 to-transparent" />
          </div>
          
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="max-w-2xl"
            >
              <span className="text-primary font-bold tracking-[0.2em] uppercase text-sm mb-4 block">
                Artisan Crafted
              </span>
              <h1 className="font-display text-5xl md:text-7xl font-bold text-foreground leading-tight mb-6">
                Illuminate Your <br />
                <span className="text-primary">Sanctuary</span>
              </h1>
              <p className="text-lg text-foreground/80 mb-8 max-w-lg leading-relaxed">
                Hand-poured luxury candles made with premium waxes and captivating fragrances. Experience warmth and elegance starting at just ₹125.
              </p>
              <div className="flex gap-4">
                <Link 
                  href="/shop" 
                  className="px-8 py-4 bg-primary text-primary-foreground rounded-full font-semibold hover:bg-primary/90 hover:shadow-xl hover:shadow-primary/20 transition-all duration-300"
                >
                  Shop Collection
                </Link>
                <Link 
                  href="/about" 
                  className="px-8 py-4 bg-transparent border-2 border-foreground/10 text-foreground rounded-full font-semibold hover:border-foreground hover:bg-foreground/5 transition-all duration-300"
                >
                  Our Story
                </Link>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Featured Products */}
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-end mb-12">
              <div>
                <h2 className="font-display text-4xl font-bold text-foreground mb-4">Featured Scents</h2>
                <p className="text-muted-foreground max-w-md">Discover our most loved fragrances, hand-picked for the season.</p>
              </div>
              <Link href="/shop" className="hidden md:flex items-center gap-2 text-primary font-semibold hover:underline">
                View All <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="animate-pulse bg-secondary rounded-xl h-[400px]" />
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {featuredProducts.map((product, index) => (
                  <ProductCard key={product.id} product={product} index={index} />
                ))}
              </div>
            )}
            
            <div className="mt-8 text-center md:hidden">
              <Link href="/shop" className="inline-flex items-center gap-2 text-primary font-semibold hover:underline">
                View All Collection <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section className="py-24 bg-secondary/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <motion.div 
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="order-2 lg:order-1"
              >
                <img 
                  src={`${import.meta.env.BASE_URL}images/about-candle.png`} 
                  alt="Candle making process" 
                  className="rounded-2xl shadow-2xl object-cover h-[500px] w-full"
                />
              </motion.div>
              
              <motion.div 
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="order-1 lg:order-2"
              >
                <span className="text-primary font-bold tracking-widest uppercase text-sm mb-4 block">
                  The Craft
                </span>
                <h2 className="font-display text-4xl lg:text-5xl font-bold text-foreground mb-6 leading-tight">
                  Hand-Poured with Intention
                </h2>
                <p className="text-muted-foreground text-lg mb-6 leading-relaxed">
                  Every Flint and Light candle is meticulously crafted by artisans who understand that a candle is more than just wax and a wick—it's an experience. 
                </p>
                <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
                  We use only premium, sustainable ingredients to ensure a clean burn and a fragrance throw that beautifully fills your space, turning ordinary moments into luxurious rituals.
                </p>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-display font-bold text-xl mb-2">100% Natural</h4>
                    <p className="text-sm text-muted-foreground">Eco-friendly wax blends for a clean burn.</p>
                  </div>
                  <div>
                    <h4 className="font-display font-bold text-xl mb-2">Artisan Made</h4>
                    <p className="text-sm text-muted-foreground">Crafted by hand in small, quality batches.</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
        
        {/* Testimonials */}
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="font-display text-4xl font-bold text-foreground mb-16">Loved by Customers</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { name: "Priya S.", comment: "The Lavender Amber candle completely transformed my living room. Such a luxurious scent for the price!", rating: 5 },
                { name: "Rahul M.", comment: "Excellent packaging and beautiful burn. Flint & Light is now my go-to for gifting.", rating: 5 },
                { name: "Anita K.", comment: "I've tried many expensive brands, but these rival them all. The earthy tones are perfect.", rating: 5 }
              ].map((testimonial, i) => (
                <div key={i} className="bg-card p-8 rounded-2xl shadow-sm border border-border/50 text-center">
                  <div className="flex justify-center gap-1 mb-4 text-primary">
                    {[...Array(testimonial.rating)].map((_, j) => <Star key={j} className="w-5 h-5 fill-current" />)}
                  </div>
                  <p className="text-foreground/80 italic mb-6">"{testimonial.comment}"</p>
                  <h4 className="font-bold text-foreground">— {testimonial.name}</h4>
                </div>
              ))}
            </div>
            
            <div className="mt-12">
              <Link href="/reviews" className="px-6 py-3 bg-secondary text-secondary-foreground rounded-full font-semibold hover:bg-secondary/80 transition-colors">
                Read All Reviews
              </Link>
            </div>
          </div>
        </section>

      </main>
      
      <Footer />
    </div>
  );
}
