import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Navbar } from "@/components/layout/Navbar";
import { useCart } from "@/store/use-cart";
import { useCreateOrder } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Loader2, Lock } from "lucide-react";
import { Link } from "wouter";

const checkoutSchema = z.object({
  customerName: z.string().min(2, "Name is required"),
  customerEmail: z.string().email("Valid email is required"),
  customerPhone: z.string().min(10, "Valid phone number is required"),
  address: z.string().min(5, "Full address is required"),
  city: z.string().min(2, "City is required"),
  pincode: z.string().min(6, "Valid pincode is required"),
});

type CheckoutForm = z.infer<typeof checkoutSchema>;

export function Checkout() {
  const [, setLocation] = useLocation();
  const { items, totalAmount, clearCart } = useCart();
  const { toast } = useToast();
  
  const { mutate: createOrder, isPending } = useCreateOrder({
    mutation: {
      onSuccess: () => {
        clearCart();
        toast({ title: "Order Placed Successfully!", description: "Thank you for shopping with Flint & Light." });
        setLocation("/order-confirmation");
      },
      onError: (error) => {
        toast({ 
          title: "Order Failed", 
          description: error instanceof Error ? error.message : "Something went wrong.",
          variant: "destructive"
        });
      }
    }
  });

  const { register, handleSubmit, formState: { errors } } = useForm<CheckoutForm>({
    resolver: zodResolver(checkoutSchema)
  });

  const onSubmit = (data: CheckoutForm) => {
    if (items.length === 0) return;
    
    createOrder({
      data: {
        ...data,
        items: items.map(item => ({
          productId: item.product.id,
          quantity: item.quantity
        }))
      }
    });
  };

  if (items.length === 0 && !isPending) {
    setLocation("/cart");
    return null;
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="py-6 bg-card border-b border-border sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
          <Link href="/cart" className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4" /> Back to Cart
          </Link>
          <span className="font-display font-bold text-2xl tracking-wide">Flint & Light</span>
          <div className="flex items-center gap-2 text-muted-foreground text-sm">
            <Lock className="w-4 h-4" /> Secure Checkout
          </div>
        </div>
      </header>

      <main className="flex-grow py-12">
        <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-12">
          
          {/* Form */}
          <div>
            <h2 className="font-display text-3xl font-bold mb-8">Shipping Information</h2>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              
              <div className="space-y-4">
                <h3 className="font-semibold text-lg border-b border-border pb-2">Contact Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Full Name</label>
                    <input 
                      {...register("customerName")}
                      className="w-full px-4 py-3 rounded-xl bg-card border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all" 
                      placeholder="Jane Doe"
                    />
                    {errors.customerName && <p className="text-destructive text-sm mt-1">{errors.customerName.message}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Email</label>
                    <input 
                      {...register("customerEmail")}
                      type="email"
                      className="w-full px-4 py-3 rounded-xl bg-card border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all" 
                      placeholder="jane@example.com"
                    />
                    {errors.customerEmail && <p className="text-destructive text-sm mt-1">{errors.customerEmail.message}</p>}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Phone Number</label>
                  <input 
                    {...register("customerPhone")}
                    className="w-full px-4 py-3 rounded-xl bg-card border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all" 
                    placeholder="+91 9876543210"
                  />
                  {errors.customerPhone && <p className="text-destructive text-sm mt-1">{errors.customerPhone.message}</p>}
                </div>
              </div>

              <div className="space-y-4 pt-4">
                <h3 className="font-semibold text-lg border-b border-border pb-2">Delivery Address</h3>
                <div>
                  <label className="block text-sm font-medium mb-1">Address</label>
                  <input 
                    {...register("address")}
                    className="w-full px-4 py-3 rounded-xl bg-card border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all" 
                    placeholder="123 Artisan Street, Apt 4B"
                  />
                  {errors.address && <p className="text-destructive text-sm mt-1">{errors.address.message}</p>}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">City</label>
                    <input 
                      {...register("city")}
                      className="w-full px-4 py-3 rounded-xl bg-card border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all" 
                      placeholder="Mumbai"
                    />
                    {errors.city && <p className="text-destructive text-sm mt-1">{errors.city.message}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Pincode</label>
                    <input 
                      {...register("pincode")}
                      className="w-full px-4 py-3 rounded-xl bg-card border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all" 
                      placeholder="400001"
                    />
                    {errors.pincode && <p className="text-destructive text-sm mt-1">{errors.pincode.message}</p>}
                  </div>
                </div>
              </div>

              <button 
                type="submit"
                disabled={isPending}
                className="w-full py-4 mt-8 bg-primary text-primary-foreground rounded-xl font-bold text-lg shadow-lg hover:bg-primary/90 transition-all flex justify-center items-center gap-2 disabled:opacity-70"
              >
                {isPending ? (
                  <><Loader2 className="w-5 h-5 animate-spin" /> Processing...</>
                ) : (
                  `Pay ₹${totalAmount().toLocaleString()}`
                )}
              </button>
            </form>
          </div>

          {/* Order Summary */}
          <div className="bg-card p-8 rounded-2xl shadow-sm border border-border h-fit sticky top-28">
            <h3 className="font-display font-bold text-2xl mb-6 border-b border-border pb-4">Order Summary</h3>
            
            <div className="space-y-4 mb-6 max-h-96 overflow-y-auto pr-2">
              {items.map((item) => (
                <div key={item.product.id} className="flex gap-4">
                  <div className="w-16 h-16 bg-secondary rounded-lg overflow-hidden shrink-0 border border-border">
                    <img 
                      src={item.product.imageUrl || `${import.meta.env.BASE_URL}images/placeholder-candle.png`} 
                      alt={item.product.name}
                      className="w-full h-full object-cover" 
                    />
                  </div>
                  <div className="flex-grow flex flex-col justify-center">
                    <div className="flex justify-between">
                      <span className="font-medium">{item.product.name}</span>
                      <span className="font-medium">₹{(item.product.price * item.quantity).toLocaleString()}</span>
                    </div>
                    <span className="text-sm text-muted-foreground">Qty: {item.quantity}</span>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="space-y-3 pt-6 border-t border-border text-sm">
              <div className="flex justify-between text-muted-foreground">
                <span>Subtotal</span>
                <span>₹{totalAmount().toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>Shipping</span>
                <span className="text-primary font-medium">Free</span>
              </div>
              <div className="flex justify-between font-bold text-xl text-foreground pt-4 border-t border-border">
                <span>Total</span>
                <span>₹{totalAmount().toLocaleString()}</span>
              </div>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}
