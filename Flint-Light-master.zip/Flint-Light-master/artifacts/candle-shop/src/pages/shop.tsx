import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { useListProducts } from "@workspace/api-client-react";
import { ProductCard } from "@/components/ui/ProductCard";
import { Search } from "lucide-react";

export function Shop() {
  const { data: products, isLoading } = useListProducts();
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  
  const categories = ["all", ...Array.from(new Set(products?.map(p => p.category) || []))];
  
  const filteredProducts = products?.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) || 
                          p.description.toLowerCase().includes(search.toLowerCase());
    const matchesCat = category === "all" || p.category === category;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-grow pt-32 pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center mb-16">
            <h1 className="font-display text-5xl font-bold text-foreground mb-4">Our Collection</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Explore our artisan crafted candles, each poured with intention to bring warmth and elegance to your space.
            </p>
          </div>
          
          <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-12">
            {/* Categories */}
            <div className="flex flex-wrap gap-2 justify-center">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`px-4 py-2 rounded-full text-sm font-semibold capitalize transition-all ${
                    category === cat 
                      ? "bg-primary text-primary-foreground shadow-md" 
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
            
            {/* Search */}
            <div className="relative w-full md:w-72">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input 
                type="text"
                placeholder="Search candles..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-full bg-card border border-border focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all"
              />
            </div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="animate-pulse bg-secondary rounded-xl h-[400px]" />
              ))}
            </div>
          ) : filteredProducts?.length === 0 ? (
            <div className="text-center py-24 bg-card rounded-2xl border border-border border-dashed">
              <h3 className="font-display text-2xl font-bold mb-2">No products found</h3>
              <p className="text-muted-foreground">Try adjusting your search or filters.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {filteredProducts?.map((product, index) => (
                <ProductCard key={product.id} product={product} index={index} />
              ))}
            </div>
          )}
          
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
