import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useState, useEffect } from "react";
import { Dashboard } from "@/pages/dashboard";
import NotFound from "@/pages/not-found";
import { Lock, Eye, EyeOff } from "lucide-react";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5,
    }
  }
});

const CORRECT_PASSWORD = "Ganyth";
const SESSION_KEY = "fnl_portal_auth";

function PasswordGate({ onUnlock }: { onUnlock: () => void }) {
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [shaking, setShaking] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === CORRECT_PASSWORD) {
      sessionStorage.setItem(SESSION_KEY, "true");
      onUnlock();
    } else {
      setError("Incorrect password. Please try again.");
      setShaking(true);
      setTimeout(() => setShaking(false), 600);
      setPassword("");
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className={`w-full max-w-sm ${shaking ? "animate-shake" : ""}`}>
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-2">
            <img
              src={`${import.meta.env.BASE_URL}logo.png`}
              alt="Flint & Light"
              className="h-12 w-12 object-contain brightness-0 invert"
            />
            <div>
              <span className="font-bold text-2xl tracking-wide text-foreground block leading-tight">Flint & Light</span>
              <span className="text-[9px] tracking-[0.18em] text-primary/80 uppercase font-medium">
                Subtle Flame · Lasting Presence
              </span>
            </div>
          </div>
          <div className="flex items-center justify-center gap-2 text-muted-foreground mb-2">
            <Lock className="w-4 h-4" />
            <span className="text-sm font-medium uppercase tracking-widest">Owner Portal</span>
          </div>
          <p className="text-muted-foreground text-sm">Enter your password to access the dashboard.</p>
        </div>

        {/* Card */}
        <div className="bg-card border border-border rounded-2xl p-8 shadow-xl">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); setError(""); }}
                  placeholder="Enter password"
                  autoFocus
                  className="w-full px-4 py-3 pr-12 rounded-xl bg-background border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none text-foreground placeholder:text-muted-foreground transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {error && <p className="text-destructive text-xs mt-2">{error}</p>}
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-primary text-primary-foreground font-semibold rounded-xl hover:opacity-90 transition-opacity"
            >
              Unlock Portal
            </button>
          </form>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-6">
          This is a private page. Unauthorised access is prohibited.
        </p>
      </div>

      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          10%, 50%, 90% { transform: translateX(-8px); }
          30%, 70% { transform: translateX(8px); }
        }
        .animate-shake { animation: shake 0.5s ease-in-out; }
      `}</style>
    </div>
  );
}

function App() {
  const [unlocked, setUnlocked] = useState(() => {
    return sessionStorage.getItem(SESSION_KEY) === "true";
  });

  useEffect(() => {
    if (!unlocked) {
      sessionStorage.removeItem(SESSION_KEY);
    }
  }, [unlocked]);

  if (!unlocked) {
    return (
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <PasswordGate onUnlock={() => setUnlocked(true)} />
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Switch>
            <Route path="/" component={() => <Dashboard onLock={() => { sessionStorage.removeItem(SESSION_KEY); setUnlocked(false); }} />} />
            <Route component={NotFound} />
          </Switch>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
