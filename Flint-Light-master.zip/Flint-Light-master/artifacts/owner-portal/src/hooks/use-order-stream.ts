import { useEffect, useRef, useState } from "react";

export function useOrderStream() {
  const [newOrder, setNewOrder] = useState<unknown>(null);
  const eventSourceRef = useRef<EventSource | null>(null);

  useEffect(() => {
    const es = new EventSource("/api/orders/stream");
    eventSourceRef.current = es;

    es.onmessage = (event) => {
      try {
        const order = JSON.parse(event.data);
        setNewOrder(order);
        // Clear after 5 seconds
        setTimeout(() => setNewOrder(null), 5000);
      } catch {
        // ignore parse errors
      }
    };

    return () => {
      es.close();
    };
  }, []);

  return newOrder;
}
