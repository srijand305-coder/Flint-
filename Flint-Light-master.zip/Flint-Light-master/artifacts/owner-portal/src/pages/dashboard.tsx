import { useState } from "react";
import { 
  useListOrders, useUpdateOrderStatus, useDeleteOrder,
  useListProducts, useCreateProduct, useDeleteProduct,
  useListReviews, useDeleteReview,
  useListBannedUsers, useBanUser, useUnbanUser,
} from "@workspace/api-client-react";
import { useOrderStream } from "@/hooks/use-order-stream";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { Package, ShoppingBag, Star, Plus, Trash2, LogOut, Activity, ExternalLink, ShieldBan, ShieldCheck } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const productSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  price: z.coerce.number().min(1, "Price must be at least ₹1"),
  imageUrl: z.string().url("Must be a valid URL"),
  category: z.string().min(2, "Category is required"),
  inStock: z.boolean().default(true),
});

type ProductForm = z.infer<typeof productSchema>;

export function Dashboard({ onLock }: { onLock: () => void }) {
  const [activeTab, setActiveTab] = useState<"orders" | "products" | "reviews" | "banned">("orders");
  const [isAddProductOpen, setIsAddProductOpen] = useState(false);
  
  const { toast } = useToast();
  const newOrder = useOrderStream();

  const { data: orders, refetch: refetchOrders } = useListOrders();
  const { data: products, refetch: refetchProducts } = useListProducts();
  const { data: reviews, refetch: refetchReviews } = useListReviews();

  const { mutate: updateStatus } = useUpdateOrderStatus({ onSuccess: () => refetchOrders() });
  const { mutate: deleteOrder } = useDeleteOrder({ onSuccess: () => { toast({ title: "Order deleted" }); refetchOrders(); } });
  const { mutate: deleteProduct } = useDeleteProduct({ onSuccess: () => { toast({ title: "Product deleted" }); refetchProducts(); } });
  const { mutate: deleteReview } = useDeleteReview({ onSuccess: () => { toast({ title: "Review deleted" }); refetchReviews(); } });

  const { data: bannedUsers, refetch: refetchBanned } = useListBannedUsers();
  const { mutate: banUser } = useBanUser({ mutation: { onSuccess: () => { toast({ title: "User banned" }); refetchBanned(); } } });
  const { mutate: unbanUser } = useUnbanUser({ mutation: { onSuccess: () => { toast({ title: "User unbanned" }); refetchBanned(); } } });

  const handleBan = (customerName: string) => {
    const reason = prompt(`Ban "${customerName}"?\n\nOptional reason (press OK to confirm, Cancel to abort):`) ?? null;
    if (reason === null) return;
    banUser({ data: { customerName, reason: reason || undefined } });
  };
  
  const { mutate: createProduct, isPending: isAddingProduct } = useCreateProduct({
    mutation: {
      onSuccess: () => {
        toast({ title: "Product added successfully!" });
        setIsAddProductOpen(false);
        resetProductForm();
        refetchProducts();
      },
      onError: () => {
        toast({ title: "Failed to add product", variant: "destructive" });
      }
    }
  });

  const { register, handleSubmit, reset: resetProductForm, formState: { errors } } = useForm<ProductForm>({
    resolver: zodResolver(productSchema),
    defaultValues: { inStock: true }
  });

  const onSubmitProduct = (data: ProductForm) => createProduct({ data });

  const totalRevenue = orders?.filter(o => o.status !== "cancelled").reduce((sum, o) => sum + o.totalAmount, 0) || 0;
  const avgRating = reviews?.length ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1) : "0.0";

  const tabs = [
    { id: "orders" as const, label: "Orders", icon: ShoppingBag },
    { id: "products" as const, label: "Products", icon: Package },
    { id: "reviews" as const, label: "Reviews", icon: Star },
    { id: "banned" as const, label: "Banned Users", icon: ShieldBan },
  ];

  return (
    <div className="min-h-screen bg-background flex">
      
      {/* Sidebar */}
      <aside className="w-60 bg-card border-r border-border hidden md:flex flex-col fixed left-0 top-0 h-full">
        <div className="p-5 border-b border-border">
          <div className="flex items-center gap-2">
            <img
              src={`${import.meta.env.BASE_URL}logo.png`}
              alt="Flint & Light"
              className="h-8 w-8 object-contain brightness-0 invert"
            />
            <div>
              <p className="font-bold text-sm text-foreground leading-tight">Flint & Light</p>
              <p className="text-[8px] tracking-[0.15em] text-primary/70 uppercase font-medium leading-tight">Subtle Flame · Lasting Presence</p>
            </div>
          </div>
        </div>

        {newOrder && (
          <div className="mx-3 mt-3 flex items-center gap-2 bg-primary/10 text-primary px-3 py-2 rounded-lg text-xs font-bold animate-pulse border border-primary/20">
            <Activity className="w-3 h-3" /> New Order!
          </div>
        )}

        <nav className="p-3 space-y-1 flex-grow">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                activeTab === id 
                  ? "bg-primary text-primary-foreground" 
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              }`}
            >
              <Icon className="w-4 h-4" /> {label}
              {id === "orders" && orders && orders.length > 0 && (
                <span className={`ml-auto text-xs font-bold px-1.5 py-0.5 rounded-full ${activeTab === id ? 'bg-primary-foreground/20 text-primary-foreground' : 'bg-secondary text-muted-foreground'}`}>
                  {orders.length}
                </span>
              )}
            </button>
          ))}
        </nav>

        <div className="p-3 border-t border-border space-y-1">
          <a 
            href="/" 
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
          >
            <ExternalLink className="w-4 h-4" /> View Store
          </a>
          <button
            onClick={onLock}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors"
          >
            <LogOut className="w-4 h-4" /> Lock Portal
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow ml-0 md:ml-60 p-4 md:p-8">
        
        {/* Header */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold text-foreground capitalize">{activeTab}</h1>
            {activeTab === "products" && (
              <button
                onClick={() => setIsAddProductOpen(true)}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-xl font-semibold flex items-center gap-2 hover:opacity-90 transition-opacity text-sm"
              >
                <Plus className="w-4 h-4" /> Add Product
              </button>
            )}
          </div>
          
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: "Total Revenue", value: `₹${totalRevenue.toLocaleString()}`, highlight: true },
              { label: "Total Orders", value: orders?.length || 0 },
              { label: "Products", value: products?.length || 0 },
              { label: "Avg Rating", value: `${avgRating} ★` },
            ].map(({ label, value, highlight }) => (
              <div key={label} className="bg-card border border-border rounded-2xl p-5">
                <p className="text-muted-foreground text-xs font-semibold uppercase tracking-wide mb-2">{label}</p>
                <p className={`text-2xl font-bold ${highlight ? 'text-primary' : 'text-foreground'}`}>{value}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          
          {/* ORDERS */}
          {activeTab === "orders" && (
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-border bg-secondary/30 text-muted-foreground text-xs uppercase tracking-wider">
                    <th className="p-4 font-semibold">Order</th>
                    <th className="p-4 font-semibold">Customer</th>
                    <th className="p-4 font-semibold">Address</th>
                    <th className="p-4 font-semibold">Items</th>
                    <th className="p-4 font-semibold">Total</th>
                    <th className="p-4 font-semibold">Status</th>
                    <th className="p-4 font-semibold text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {orders?.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(order => (
                    <tr key={order.id} className="hover:bg-secondary/20 transition-colors">
                      <td className="p-4">
                        <p className="font-bold text-primary text-sm">#{order.id.toString().padStart(4, '0')}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{format(new Date(order.createdAt), 'MMM d, yyyy')}</p>
                      </td>
                      <td className="p-4">
                        <p className="font-semibold text-foreground text-sm">{order.customerName}</p>
                        <p className="text-xs text-muted-foreground">{order.customerEmail}</p>
                      </td>
                      <td className="p-4">
                        <p className="text-sm text-foreground">{order.address}</p>
                        <p className="text-xs text-muted-foreground">{order.city} – {order.pincode}</p>
                      </td>
                      <td className="p-4">
                        <div className="space-y-0.5">
                          {order.items.map((item, i) => (
                            <p key={i} className="text-xs text-muted-foreground">
                              {item.productName} × {item.quantity}
                            </p>
                          ))}
                        </div>
                      </td>
                      <td className="p-4 font-bold text-foreground">₹{order.totalAmount.toLocaleString()}</td>
                      <td className="p-4">
                        <select
                          value={order.status}
                          onChange={(e) => updateStatus({ id: order.id, data: { status: e.target.value as "pending" | "confirmed" | "shipped" | "delivered" | "cancelled" } })}
                          className={`text-xs font-bold px-3 py-1.5 rounded-full border outline-none cursor-pointer bg-transparent ${
                            order.status === 'delivered' ? 'text-green-400 border-green-400/30 bg-green-400/10' :
                            order.status === 'cancelled' ? 'text-destructive border-destructive/30 bg-destructive/10' :
                            order.status === 'shipped' ? 'text-blue-400 border-blue-400/30 bg-blue-400/10' :
                            'text-primary border-primary/30 bg-primary/10'
                          }`}
                        >
                          <option value="pending">Pending</option>
                          <option value="confirmed">Confirmed</option>
                          <option value="shipped">Shipped</option>
                          <option value="delivered">Delivered</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => { if (confirm('Delete this order?')) deleteOrder({ id: order.id }); }}
                          className="p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {(!orders || orders.length === 0) && (
                    <tr><td colSpan={7} className="p-12 text-center text-muted-foreground">No orders yet.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* PRODUCTS */}
          {activeTab === "products" && (
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-border bg-secondary/30 text-muted-foreground text-xs uppercase tracking-wider">
                    <th className="p-4 font-semibold">Product</th>
                    <th className="p-4 font-semibold">Category</th>
                    <th className="p-4 font-semibold">Price</th>
                    <th className="p-4 font-semibold">Stock</th>
                    <th className="p-4 font-semibold text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {products?.map(product => (
                    <tr key={product.id} className="hover:bg-secondary/20 transition-colors">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <img src={product.imageUrl} alt={product.name} className="w-10 h-10 rounded-lg object-cover border border-border" />
                          <div>
                            <p className="font-semibold text-foreground text-sm">{product.name}</p>
                            <p className="text-xs text-muted-foreground line-clamp-1 max-w-xs">{product.description}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-sm text-muted-foreground">{product.category}</td>
                      <td className="p-4 font-bold text-foreground">₹{product.price.toLocaleString()}</td>
                      <td className="p-4">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${product.inStock ? 'bg-green-400/10 text-green-400 border border-green-400/20' : 'bg-destructive/10 text-destructive border border-destructive/20'}`}>
                          {product.inStock ? 'In Stock' : 'Out of Stock'}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => { if (confirm('Delete this product?')) deleteProduct({ id: product.id }); }}
                          className="p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {(!products || products.length === 0) && (
                    <tr><td colSpan={5} className="p-12 text-center text-muted-foreground">No products found.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* REVIEWS */}
          {activeTab === "reviews" && (
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-border bg-secondary/30 text-muted-foreground text-xs uppercase tracking-wider">
                    <th className="p-4 font-semibold">Customer</th>
                    <th className="p-4 font-semibold">Product</th>
                    <th className="p-4 font-semibold">Rating</th>
                    <th className="p-4 font-semibold">Comment</th>
                    <th className="p-4 font-semibold">Date</th>
                    <th className="p-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {reviews?.map(review => {
                    const isBanned = bannedUsers?.some(b => b.customerName === review.customerName);
                    return (
                      <tr key={review.id} className="hover:bg-secondary/20 transition-colors">
                        <td className="p-4">
                          <p className="font-semibold text-foreground text-sm">{review.customerName}</p>
                          {isBanned && (
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-destructive bg-destructive/10 px-1.5 py-0.5 rounded mt-0.5">
                              <ShieldBan className="w-2.5 h-2.5" /> Banned
                            </span>
                          )}
                        </td>
                        <td className="p-4 text-sm text-muted-foreground">{review.productName}</td>
                        <td className="p-4">
                          <div className="flex gap-0.5 text-primary">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star key={i} className={`w-3.5 h-3.5 ${i < review.rating ? 'fill-current' : 'opacity-20'}`} />
                            ))}
                          </div>
                        </td>
                        <td className="p-4 text-sm text-muted-foreground max-w-sm">
                          <p className="line-clamp-2">{review.comment}</p>
                        </td>
                        <td className="p-4 text-xs text-muted-foreground whitespace-nowrap">
                          {format(new Date(review.createdAt), 'MMM d, yyyy')}
                        </td>
                        <td className="p-4 text-right">
                          <div className="flex items-center gap-1 justify-end">
                            {!isBanned ? (
                              <button
                                onClick={() => handleBan(review.customerName)}
                                title="Ban this user"
                                className="p-2 text-muted-foreground hover:bg-orange-500/10 hover:text-orange-500 rounded-lg transition-colors"
                              >
                                <ShieldBan className="w-4 h-4" />
                              </button>
                            ) : (
                              <button
                                onClick={() => { const b = bannedUsers?.find(u => u.customerName === review.customerName); if (b) unbanUser({ id: b.id }); }}
                                title="Unban this user"
                                className="p-2 text-muted-foreground hover:bg-green-500/10 hover:text-green-500 rounded-lg transition-colors"
                              >
                                <ShieldCheck className="w-4 h-4" />
                              </button>
                            )}
                            <button
                              onClick={() => { if (confirm('Delete this review?')) deleteReview({ id: review.id }); }}
                              className="p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive rounded-lg transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {(!reviews || reviews.length === 0) && (
                    <tr><td colSpan={6} className="p-12 text-center text-muted-foreground">No reviews yet.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === "banned" && (
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-border bg-secondary/30 text-muted-foreground text-xs uppercase tracking-wider">
                    <th className="p-4 font-semibold">Customer Name</th>
                    <th className="p-4 font-semibold">Reason</th>
                    <th className="p-4 font-semibold">Banned On</th>
                    <th className="p-4 font-semibold text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {bannedUsers?.map(b => (
                    <tr key={b.id} className="hover:bg-secondary/20 transition-colors">
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <ShieldBan className="w-4 h-4 text-destructive flex-shrink-0" />
                          <span className="font-semibold text-foreground text-sm">{b.customerName}</span>
                        </div>
                      </td>
                      <td className="p-4 text-sm text-muted-foreground">{b.reason || <span className="italic opacity-50">No reason given</span>}</td>
                      <td className="p-4 text-xs text-muted-foreground whitespace-nowrap">{format(new Date(b.bannedAt), 'MMM d, yyyy')}</td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => { if (confirm(`Unban "${b.customerName}"?`)) unbanUser({ id: b.id }); }}
                          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-green-600 bg-green-500/10 hover:bg-green-500/20 rounded-lg transition-colors ml-auto"
                        >
                          <ShieldCheck className="w-3.5 h-3.5" /> Unban
                        </button>
                      </td>
                    </tr>
                  ))}
                  {(!bannedUsers || bannedUsers.length === 0) && (
                    <tr>
                      <td colSpan={4} className="p-12 text-center text-muted-foreground">
                        <ShieldCheck className="w-10 h-10 mx-auto mb-3 opacity-20" />
                        <p>No banned users. All clear!</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>

      {/* Add Product Modal */}
      <AnimatePresence>
        {isAddProductOpen && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
              className="bg-card w-full max-w-lg rounded-2xl shadow-2xl border border-border p-6 overflow-y-auto max-h-[90vh]"
            >
              <h2 className="text-xl font-bold text-foreground mb-6">Add New Product</h2>
              <form onSubmit={handleSubmit(onSubmitProduct)} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Name</label>
                  <input
                    {...register("name")}
                    className="w-full px-4 py-2.5 rounded-xl border border-border bg-background text-foreground focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none"
                    placeholder="e.g. Rose Garden Candle"
                  />
                  {errors.name && <p className="text-destructive text-xs mt-1">{errors.name.message}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Description</label>
                  <textarea
                    {...register("description")}
                    rows={3}
                    className="w-full px-4 py-2.5 rounded-xl border border-border bg-background text-foreground focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none resize-none"
                    placeholder="Describe the scent, wax type, burn time..."
                  />
                  {errors.description && <p className="text-destructive text-xs mt-1">{errors.description.message}</p>}
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1.5">Price (₹)</label>
                    <input
                      type="number"
                      {...register("price")}
                      className="w-full px-4 py-2.5 rounded-xl border border-border bg-background text-foreground focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none"
                      placeholder="299"
                    />
                    {errors.price && <p className="text-destructive text-xs mt-1">{errors.price.message}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1.5">Category</label>
                    <input
                      {...register("category")}
                      className="w-full px-4 py-2.5 rounded-xl border border-border bg-background text-foreground focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none"
                      placeholder="e.g. Floral, Earthy"
                    />
                    {errors.category && <p className="text-destructive text-xs mt-1">{errors.category.message}</p>}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Image URL</label>
                  <input
                    {...register("imageUrl")}
                    className="w-full px-4 py-2.5 rounded-xl border border-border bg-background text-foreground focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none"
                    placeholder="https://..."
                  />
                  {errors.imageUrl && <p className="text-destructive text-xs mt-1">{errors.imageUrl.message}</p>}
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <input type="checkbox" id="inStock" {...register("inStock")} className="w-4 h-4 rounded border-border accent-primary" />
                  <label htmlFor="inStock" className="text-sm font-medium text-foreground">In Stock</label>
                </div>

                <div className="flex gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => { setIsAddProductOpen(false); resetProductForm(); }}
                    className="flex-1 py-2.5 bg-secondary text-foreground rounded-xl font-semibold hover:opacity-80 transition-opacity"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isAddingProduct}
                    className="flex-1 py-2.5 bg-primary text-primary-foreground rounded-xl font-semibold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-50"
                  >
                    {isAddingProduct ? "Saving..." : "Save Product"}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
