# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Structure

```text
artifacts-monorepo/
├── artifacts/              # Deployable applications
│   ├── api-server/         # Express API server
│   └── candle-shop/        # Flint and Light Candles storefront + dashboard
├── lib/                    # Shared libraries
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   └── db/                 # Drizzle ORM schema + DB connection
├── scripts/                # Utility scripts (single workspace package)
│   └── src/                # seed.ts - seeds products and reviews
├── pnpm-workspace.yaml
├── tsconfig.base.json
├── tsconfig.json
└── package.json
```

## Artifacts

### Flint and Light Candles (`artifacts/candle-shop`)
React + Vite artisan candle shop. Paths:
- `/` - Home landing page
- `/shop` - Product catalog with category filters + search
- `/product/:id` - Product detail + reviews
- `/cart` - Shopping cart (Zustand state)
- `/checkout` - Customer checkout form
- `/order-confirmation` - Post-order thank you
- `/reviews` - Customer review submission
- `/dashboard` - Owner dashboard (orders, products, reviews management + real-time notifications)

AI-generated product images stored in `artifacts/candle-shop/public/images/`.

### API Server (`artifacts/api-server`)
Express 5 API. Routes:
- `GET/POST /api/products`, `DELETE /api/products/:id`
- `GET/POST /api/orders`, `DELETE /api/orders/:id`, `PATCH /api/orders/:id/status`
- `GET /api/orders/stream` - SSE for real-time new order notifications
- `GET/POST /api/reviews`, `DELETE /api/reviews/:id`

## Database Schema

- `products` - Candle products with name, description, price, imageUrl, category, inStock
- `orders` - Customer orders with JSONB items array, address details, status
- `reviews` - Customer reviews with rating, comment, productId

## Seeding

Run `pnpm --filter @workspace/scripts run seed` to seed initial products and reviews.
