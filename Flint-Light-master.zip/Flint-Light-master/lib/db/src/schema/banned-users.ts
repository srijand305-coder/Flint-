import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const bannedUsersTable = pgTable("banned_users", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name").notNull().unique(),
  reason: text("reason"),
  bannedAt: timestamp("banned_at").notNull().defaultNow(),
});

export type BannedUser = typeof bannedUsersTable.$inferSelect;
